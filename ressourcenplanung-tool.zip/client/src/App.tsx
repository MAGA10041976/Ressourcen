import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { useAuth } from "./_core/hooks/useAuth";
import Home from "./pages/Home";
import Admin from "./pages/Admin";
import Gantt from "./pages/Gantt";
import Login from "./pages/Login";
import PendingApproval from "./pages/PendingApproval";
import AccessDenied from "./pages/AccessDenied";
import { Loader2 } from "lucide-react";

function AppContent() {
  const { user, loading, isAuthenticated } = useAuth();

  // Loading state
  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#07284A] to-[#005CA9] flex items-center justify-center">
        <div className="text-center text-white">
          <Loader2 className="w-10 h-10 animate-spin mx-auto mb-4" />
          <p className="text-lg">Lade Ressourcenplanung...</p>
        </div>
      </div>
    );
  }

  // Not authenticated -> Login page
  if (!isAuthenticated || !user) {
    return <Login />;
  }

  // User is rejected
  if (user.status === "rejected") {
    return <AccessDenied />;
  }

  // User is pending (not admin)
  if (user.status === "pending" && user.role !== "admin") {
    return <PendingApproval />;
  }

  // User is approved or admin -> show app
  return (
    <Switch>
      <Route path={"/"} component={Home} />
      <Route path={"/admin"} component={Admin} />
      <Route path={"/gantt"} component={Gantt} />
      <Route path={"/404"} component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster />
          <AppContent />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
