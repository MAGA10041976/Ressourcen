export function Footer() {
  return (
    <footer className="bg-[#07284A] text-white py-12">
      <div className="container">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-3 mb-3">
              <img
                src="https://d2xsxph8kpxj0f.cloudfront.net/310419663030627055/4AoWmPz5Ug2YFzAs8c8rQK/assets/zeta-logo.png"
                alt="ZETA Logo"
                className="h-7 w-auto brightness-0 invert"
              />
              <span className="font-serif text-lg text-white font-bold">
                Ressourcenplanung
              </span>
            </div>
            <p className="text-sm text-white/50 leading-relaxed">
              Interaktives Planungstool zur Visualisierung und Verwaltung der
              Projekt- und Ressourcenplanung der Abteilung Automation.
            </p>
          </div>

          {/* Navigation */}
          <div>
            <h4 className="text-sm font-semibold text-white uppercase tracking-wider mb-3">
              Sektionen
            </h4>
            <div className="space-y-2">
              {[
                { label: "Kennzahlen", href: "#kennzahlen" },
                { label: "Projektübersicht", href: "#projekte" },
                { label: "Forecast & Pipeline", href: "#forecast" },
                { label: "Projekt-Timeline", href: "/gantt" },
              ].map((item) => (
                <a
                  key={item.href}
                  href={item.href}
                  className="block text-sm text-white/50 hover:text-[#005CA9] transition-colors"
                >
                  {item.label}
                </a>
              ))}
            </div>
          </div>

          {/* Info */}
          <div>
            <h4 className="text-sm font-semibold text-white uppercase tracking-wider mb-3">
              Informationen
            </h4>
            <p className="text-sm text-white/50 leading-relaxed">
              Dieses Tool dient der Verwaltung und Visualisierung der
              Ressourcenplanung. Die dargestellten Daten werden live aus der
              Datenbank geladen und können direkt bearbeitet werden.
            </p>
            <p className="text-xs text-white/30 mt-4">
              Stand: Februar 2026
            </p>
          </div>
        </div>

        <div className="border-t border-white/10 mt-8 pt-6 flex flex-col sm:flex-row justify-between items-center gap-4">
          <p className="text-xs text-white/40">
            ZETA — Abteilung Automation — Ressourcenplanung & Forecast
          </p>
          <p className="text-xs text-white/40">
            Erstellt mit Manus AI
          </p>
        </div>
      </div>
    </footer>
  );
}
