import { motion } from "framer-motion";
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from "recharts";
import type { DbProject } from "@/lib/data";
import { trpc } from "@/lib/trpc";

interface Props {
  stats: {
    statusVerteilung: { name: string; value: number; color: string }[];
    probDistribution: { hoch: number; mittel: number; niedrig: number };
    gewichtetePipeline: number;
    angebote: number;
  };
}

// ZETA color overrides for status distribution
const ZETA_STATUS_COLORS: Record<string, string> = {
  "Laufend": "#005CA9",
  "Angebot": "#07284A",
  "In Planung": "#3B82F6",
  "Schulung": "#60A5FA",
};

export function ForecastPipeline({ stats }: Props) {
  const { data: projects } = trpc.projects.list.useQuery();

  // Override colors with ZETA palette
  const zetaStatusVerteilung = stats.statusVerteilung.map(item => ({
    ...item,
    color: ZETA_STATUS_COLORS[item.name] || item.color,
  }));

  // Build pipeline data from actual projects
  const pipelineData = (projects ?? [])
    .filter((p: DbProject) => p.status === "Angebot")
    .sort((a: DbProject, b: DbProject) => b.wahrscheinlichkeit - a.wahrscheinlichkeit)
    .map((p: DbProject) => ({
      name: `${p.kunde} - ${p.projekt}`,
      wahrscheinlichkeit: p.wahrscheinlichkeit,
    }));

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5 }}
      className="bg-white border border-border rounded-lg p-6"
    >
      <h3 className="font-serif text-2xl text-foreground font-bold mb-2">
        Projektstatus
      </h3>
      <p className="text-muted-foreground text-sm mb-6">
        Verteilung nach Projektphase und Forecast-Pipeline
      </p>

      {/* Pie Chart */}
      <div className="flex items-center justify-center mb-8">
        <div className="w-48 h-48">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={zetaStatusVerteilung}
                cx="50%"
                cy="50%"
                innerRadius={50}
                outerRadius={80}
                paddingAngle={4}
                dataKey="value"
                strokeWidth={0}
              >
                {zetaStatusVerteilung.map((entry, index) => (
                  <Cell key={index} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip
                contentStyle={{
                  background: "white",
                  border: "1px solid #e2e8f0",
                  borderRadius: "6px",
                  fontSize: "13px",
                }}
              />
            </PieChart>
          </ResponsiveContainer>
        </div>
        <div className="ml-6 space-y-3">
          {zetaStatusVerteilung.map((item) => (
            <div key={item.name} className="flex items-center gap-3">
              <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} />
              <span className="text-sm text-foreground">{item.name}</span>
              <span className="text-sm font-semibold text-foreground ml-auto">{item.value}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Pipeline bars */}
      <div className="border-t border-border pt-6">
        <h4 className="text-sm font-semibold text-foreground mb-4">
          Angebots-Pipeline ({stats.angebote} Projekte)
        </h4>
        <div className="space-y-3">
          {pipelineData.map((item: { name: string; wahrscheinlichkeit: number }, i: number) => (
            <motion.div
              key={item.name}
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.05, duration: 0.4 }}
              className="flex items-center gap-3"
            >
              <span className="text-xs text-muted-foreground w-40 truncate" title={item.name}>
                {item.name}
              </span>
              <div className="flex-1 h-3 rounded-full bg-[#f0f4f8] overflow-hidden">
                <motion.div
                  initial={{ width: 0 }}
                  whileInView={{ width: `${item.wahrscheinlichkeit}%` }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.05 + 0.2, duration: 0.6 }}
                  className={`h-full rounded-full ${
                    item.wahrscheinlichkeit >= 90
                      ? "bg-[#005CA9]"
                      : item.wahrscheinlichkeit >= 70
                      ? "bg-[#3B82F6]"
                      : item.wahrscheinlichkeit >= 50
                      ? "bg-[#60A5FA]"
                      : "bg-[#93C5FD]"
                  }`}
                />
              </div>
              <span className="text-xs font-semibold text-foreground w-10 text-right">
                {item.wahrscheinlichkeit}%
              </span>
            </motion.div>
          ))}
        </div>
      </div>
    </motion.div>
  );
}
