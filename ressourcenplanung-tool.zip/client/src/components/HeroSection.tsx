import { motion } from "framer-motion";
import { ArrowDown, BarChart3, Users, FolderKanban, FileDown } from "lucide-react";
import { exportPDF } from "@/lib/pdfExport";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

const HERO_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310419663030627055/4AoWmPz5Ug2YFzAs8c8rQK/assets/hero-automation.jpg";

interface HeroProps {
  stats: {
    total: number;
    laufend: number;
    kunden: number;
    mitarbeiter: number;
  };
}

export function HeroSection({ stats }: HeroProps) {
  const { data: projects } = trpc.projects.list.useQuery();

  const handleExport = () => {
    if (!projects || projects.length === 0) {
      toast.error("Keine Projektdaten vorhanden");
      return;
    }
    try {
      exportPDF(projects);
      toast.success("PDF erfolgreich erstellt", { description: "Die Entscheidungsvorlage wurde heruntergeladen." });
    } catch {
      toast.error("PDF-Export fehlgeschlagen");
    }
  };

  return (
    <section className="relative min-h-[90vh] flex items-end overflow-hidden">
      {/* Background image with ZETA-style dark blue overlay */}
      <div className="absolute inset-0">
        <img
          src={HERO_IMG}
          alt="Automation Netzwerk"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#07284A] via-[#07284A]/85 to-[#07284A]/50" />
      </div>

      <div className="container relative z-10 pb-16 pt-32">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-end">
          {/* Left: Title */}
          <div className="lg:col-span-7">
            <motion.div
              initial={{ opacity: 0, y: 40 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, ease: "easeOut" }}
            >
              <p className="text-[#005CA9] font-semibold text-sm tracking-widest uppercase mb-4">
                Abteilung Automation
              </p>
              <h1 className="font-serif text-4xl sm:text-5xl lg:text-6xl xl:text-7xl text-white tracking-tight leading-[1.1] font-bold">
                Ressourcen
                <br />
                <span className="text-[#005CA9]">planung</span>
              </h1>
              <p className="text-white/70 text-lg mt-6 max-w-lg leading-relaxed">
                Interaktives Planungstool zur Visualisierung Ihrer Projektlandschaft,
                Ressourcenauslastung und Forecast-Pipeline.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5, duration: 0.6 }}
              className="mt-10 flex flex-wrap gap-4"
            >
              <a
                href="#kennzahlen"
                className="inline-flex items-center gap-2 bg-[#005CA9] text-white px-6 py-3 rounded-md font-semibold text-sm hover:bg-[#004d8f] transition-colors"
              >
                Analyse starten
                <ArrowDown size={16} />
              </a>
              <button
                onClick={handleExport}
                className="inline-flex items-center gap-2 border-2 border-white/30 text-white px-6 py-3 rounded-md font-semibold text-sm hover:bg-white/10 transition-colors"
              >
                <FileDown size={16} />
                PDF exportieren
              </button>
            </motion.div>
          </div>

          {/* Right: Quick stats */}
          <div className="lg:col-span-5">
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3, duration: 0.7 }}
              className="grid grid-cols-2 gap-4"
            >
              <QuickStat icon={<FolderKanban size={20} />} value={stats.total} label="Projekte gesamt" />
              <QuickStat icon={<BarChart3 size={20} />} value={stats.laufend} label="Laufende Projekte" />
              <QuickStat icon={<Users size={20} />} value={stats.kunden} label="Kunden" />
              <QuickStat icon={<Users size={20} />} value={stats.mitarbeiter} label="Teammitglieder" />
            </motion.div>
          </div>
        </div>
      </div>

      {/* ZETA-style blue divider line */}
      <div className="absolute bottom-0 left-0 right-0 h-1 bg-[#005CA9]" />
    </section>
  );
}

function QuickStat({ icon, value, label }: { icon: React.ReactNode; value: number; label: string }) {
  return (
    <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-lg p-5 group hover:bg-white/15 transition-colors">
      <div className="text-[#005CA9] mb-3">{icon}</div>
      <p className="font-serif text-3xl text-white font-bold">{value}</p>
      <p className="text-white/60 text-sm mt-1">{label}</p>
    </div>
  );
}
