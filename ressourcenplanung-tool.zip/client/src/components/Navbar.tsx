import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Menu, X, FileDown, Loader2, LogIn, LogOut, User, Shield, Calendar } from "lucide-react";
import { exportPDF } from "@/lib/pdfExport";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";

const navItems = [
  { label: "Kennzahlen", href: "#kennzahlen" },
  { label: "Projekte", href: "#projekte" },
  { label: "Forecast", href: "#forecast" },
];

export function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [exporting, setExporting] = useState(false);
  const { data: projects } = trpc.projects.list.useQuery();
  const { user, isAuthenticated, loading: authLoading, logout } = useAuth();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const handleExport = async () => {
    if (!projects || projects.length === 0) {
      toast.error("Keine Projektdaten vorhanden");
      return;
    }
    setExporting(true);
    try {
      await new Promise((resolve) => setTimeout(resolve, 100));
      exportPDF(projects);
      toast.success("PDF erfolgreich erstellt", {
        description: "Die Entscheidungsvorlage wurde heruntergeladen.",
      });
    } catch (err) {
      console.error("PDF Export error:", err);
      toast.error("PDF-Export fehlgeschlagen", {
        description: "Bitte versuchen Sie es erneut.",
      });
    } finally {
      setExporting(false);
    }
  };

  const handleLogin = () => {
    window.location.href = getLoginUrl();
  };

  const handleLogout = async () => {
    await logout();
    toast.success("Erfolgreich abgemeldet");
  };

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? "bg-white/95 backdrop-blur-md border-b border-border shadow-sm"
          : "bg-white"
      }`}
    >
      <div className="container flex items-center justify-between h-16">
        <a href="#" className="flex items-center gap-3 group">
          <img
            src="https://d2xsxph8kpxj0f.cloudfront.net/310419663030627055/4AoWmPz5Ug2YFzAs8c8rQK/assets/zeta-logo.png"
            alt="ZETA Logo"
            className="h-8 w-auto"
          />
          <span className="font-serif text-xl font-bold text-foreground tracking-tight hidden sm:block">
            Ressourcenplanung
          </span>
        </a>

        {/* Desktop nav */}
        <div className="hidden md:flex items-center gap-6">
          {navItems.map((item) => (
            <a
              key={item.href}
              href={item.href}
              className="text-sm font-medium text-muted-foreground hover:text-primary transition-colors"
            >
              {item.label}
            </a>
          ))}
          <a
            href="/gantt"
            className="inline-flex items-center gap-1.5 text-sm font-medium text-muted-foreground hover:text-primary transition-colors"
          >
            <Calendar size={14} />
            Timeline
          </a>
          <button
            onClick={handleExport}
            disabled={exporting}
            className="inline-flex items-center gap-2 bg-primary text-white px-4 py-2 rounded-md text-sm font-semibold hover:bg-primary/90 transition-colors disabled:opacity-60"
          >
            {exporting ? (
              <Loader2 size={16} className="animate-spin" />
            ) : (
              <FileDown size={16} />
            )}
            {exporting ? "Erstelle PDF..." : "PDF Export"}
          </button>

          {/* Auth section */}
          {authLoading ? (
            <div className="w-8 h-8 flex items-center justify-center">
              <Loader2 size={16} className="animate-spin text-muted-foreground" />
            </div>
          ) : isAuthenticated ? (
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2 bg-primary/5 border border-primary/20 rounded-full px-3 py-1.5">
                <User size={14} className="text-primary" />
                <span className="text-xs font-medium text-foreground max-w-[120px] truncate">
                  {user?.name || user?.email || "Benutzer"}
                </span>
              </div>
              {user?.role === "admin" && (
                <a
                  href="/admin"
                  className="inline-flex items-center gap-1.5 text-sm font-medium text-amber-600 hover:text-amber-700 transition-colors"
                  title="Admin-Dashboard"
                >
                  <Shield size={16} />
                </a>
              )}
              <button
                onClick={handleLogout}
                className="inline-flex items-center gap-1.5 text-sm font-medium text-muted-foreground hover:text-red-600 transition-colors"
                title="Abmelden"
              >
                <LogOut size={16} />
              </button>
            </div>
          ) : (
            <button
              onClick={handleLogin}
              className="inline-flex items-center gap-2 border border-primary/30 text-primary px-4 py-2 rounded-md text-sm font-semibold hover:bg-primary/5 transition-colors"
            >
              <LogIn size={16} />
              Anmelden
            </button>
          )}
        </div>

        {/* Mobile toggle */}
        <div className="md:hidden flex items-center gap-2">
          <button
            onClick={handleExport}
            disabled={exporting}
            className="p-2 text-primary"
            title="PDF exportieren"
          >
            {exporting ? (
              <Loader2 size={20} className="animate-spin" />
            ) : (
              <FileDown size={20} />
            )}
          </button>
          <button
            className="p-2 text-foreground"
            onClick={() => setMobileOpen(!mobileOpen)}
          >
            {mobileOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-white border-b border-border overflow-hidden"
          >
            <div className="container py-4 flex flex-col gap-3">
              {navItems.map((item) => (
                <a
                  key={item.href}
                  href={item.href}
                  className="text-sm font-medium text-muted-foreground hover:text-primary py-2"
                  onClick={() => setMobileOpen(false)}
                >
                  {item.label}
                </a>
              ))}
              <a
                href="/gantt"
                className="flex items-center gap-2 text-sm font-medium text-muted-foreground hover:text-primary py-2"
                onClick={() => setMobileOpen(false)}
              >
                <Calendar size={14} />
                Timeline
              </a>
              <button
                onClick={() => { setMobileOpen(false); handleExport(); }}
                disabled={exporting}
                className="flex items-center gap-2 text-sm font-semibold text-primary py-2"
              >
                <FileDown size={16} />
                PDF exportieren
              </button>

              {/* Mobile auth */}
              <div className="border-t border-border pt-3 mt-1">
                {authLoading ? (
                  <div className="flex items-center gap-2 py-2">
                    <Loader2 size={16} className="animate-spin text-muted-foreground" />
                    <span className="text-sm text-muted-foreground">Laden...</span>
                  </div>
                ) : isAuthenticated ? (
                  <div className="flex flex-col gap-2">
                    <div className="flex items-center gap-2 py-1">
                      <User size={16} className="text-primary" />
                      <span className="text-sm font-medium text-foreground">
                        {user?.name || user?.email || "Benutzer"}
                      </span>
                    </div>
                    {user?.role === "admin" && (
                      <a
                        href="/admin"
                        onClick={() => setMobileOpen(false)}
                        className="flex items-center gap-2 text-sm font-medium text-amber-600 py-2"
                      >
                        <Shield size={16} />
                        Admin-Dashboard
                      </a>
                    )}
                    <button
                      onClick={() => { setMobileOpen(false); handleLogout(); }}
                      className="flex items-center gap-2 text-sm font-medium text-red-600 py-2"
                    >
                      <LogOut size={16} />
                      Abmelden
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={() => { setMobileOpen(false); handleLogin(); }}
                    className="flex items-center gap-2 text-sm font-semibold text-primary py-2"
                  >
                    <LogIn size={16} />
                    Anmelden
                  </button>
                )}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}
