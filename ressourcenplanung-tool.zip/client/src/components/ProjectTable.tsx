import { useState, useMemo, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import type { DbProject } from "@/lib/data";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import {
  ChevronDown,
  ChevronUp,
  Filter,
  Search,
  Pencil,
  Trash2,
  Save,
  X,
  Plus,
  Loader2,
  Download,
  Upload,
} from "lucide-react";

interface Props {
  projects: DbProject[];
  isLoading?: boolean;
  isAuthenticated?: boolean;
}

type EditableProject = {
  kunde: string;
  projekt: string;
  status: DbProject["status"];
  geplanterStart: string;
  bestellung: number;
  mentorSupport: string;
  ktmLead: string;
  mitarbeiter: string;
  qaa: string;
  stunden: number | null;
  wahrscheinlichkeit: number;
  bemerkung: string;
};

const statusOptions: DbProject["status"][] = ["Angebot", "BD", "BD/DD", "CD", "DD", "läuft"];

const statusColors: Record<string, string> = {
  "läuft": "bg-[#005CA9]/15 text-[#005CA9]",
  Angebot: "bg-[#07284A]/10 text-[#07284A]",
  BD: "bg-blue-100 text-blue-800",
  "BD/DD": "bg-blue-50 text-[#005CA9]",
  CD: "bg-[#005CA9]/10 text-[#005CA9]",
  DD: "bg-sky-100 text-sky-800",
};


const probColors = (p: number) => {
  if (p >= 90) return "bg-[#005CA9]";
  if (p >= 70) return "bg-[#3B82F6]";
  if (p >= 50) return "bg-[#60A5FA]";
  return "bg-[#93C5FD]";
};

const emptyProject: EditableProject = {
  kunde: "",
  projekt: "",
  status: "Angebot",
  geplanterStart: "",
  bestellung: 0,
  mentorSupport: "",
  ktmLead: "",
  mitarbeiter: "",
  qaa: "",
  stunden: null,
  wahrscheinlichkeit: 50,
  bemerkung: "",
};

export function ProjectTable({ projects, isLoading, isAuthenticated = false }: Props) {
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("alle");
  const [sortField, setSortField] = useState<keyof DbProject>("wahrscheinlichkeit");
  const [sortDir, setSortDir] = useState<"asc" | "desc">("desc");
  const [expandedId, setExpandedId] = useState<number | null>(null);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editData, setEditData] = useState<EditableProject>(emptyProject);
  const [showNewForm, setShowNewForm] = useState(false);
  const [newData, setNewData] = useState<EditableProject>({ ...emptyProject });

  const utils = trpc.useUtils();
  const csvImportMutation = trpc.projects.importCsv.useMutation({
    onSuccess: (result: { imported: number }) => {
      utils.projects.list.invalidate();
      toast.success(`${result.imported} Projekte importiert`);
    },
    onError: (err: { message: string }) => {
      toast.error(`Import-Fehler: ${err.message}`);
    },
  });

  const handleCsvExport = useCallback(() => {
    if (!projects.length) {
      toast.error("Keine Projekte zum Exportieren");
      return;
    }
    const headers = ["Kunde", "Projekt", "Status", "Geplanter Start", "Bestellung", "Mentor/Support", "KTM Lead", "Mitarbeiter", "QAA", "Stunden", "Wahrscheinlichkeit", "Bemerkung"];
    const escCsv = (v: string) => {
      if (v.includes('"') || v.includes(';') || v.includes('\n')) {
        return '"' + v.replace(/"/g, '""') + '"';
      }
      return v;
    };
    const rows = projects.map((p) => [
      escCsv(p.kunde),
      escCsv(p.projekt),
      escCsv(p.status),
      escCsv(p.geplanterStart || ""),
      p.bestellung ? "Ja" : "Nein",
      escCsv(p.mentorSupport || ""),
      escCsv(p.ktmLead || ""),
      escCsv(p.mitarbeiter || ""),
      escCsv(p.qaa || ""),
      p.stunden != null ? String(p.stunden) : "",
      String(p.wahrscheinlichkeit) + "%",
      escCsv(p.bemerkung || ""),
    ].join(";"));
    const bom = "\uFEFF";
    const csv = bom + headers.join(";") + "\n" + rows.join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `Ressourcenplanung_${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success("CSV-Datei heruntergeladen");
  }, [projects]);

  const handleCsvImport = useCallback(() => {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = ".csv";
    input.onchange = async (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (!file) return;
      const text = await file.text();
      csvImportMutation.mutate({ csvData: text });
    };
    input.click();
  }, [csvImportMutation]);

  const updateMutation = trpc.projects.update.useMutation({
    onSuccess: () => {
      utils.projects.list.invalidate();
      setEditingId(null);
      toast.success("Projekt erfolgreich gespeichert");
    },
    onError: (err) => {
      toast.error(`Fehler beim Speichern: ${err.message}`);
    },
  });

  const createMutation = trpc.projects.create.useMutation({
    onSuccess: () => {
      utils.projects.list.invalidate();
      setShowNewForm(false);
      setNewData({ ...emptyProject });
      toast.success("Neues Projekt erfolgreich erstellt");
    },
    onError: (err) => {
      toast.error(`Fehler beim Erstellen: ${err.message}`);
    },
  });

  const deleteMutation = trpc.projects.delete.useMutation({
    onSuccess: () => {
      utils.projects.list.invalidate();
      setExpandedId(null);
      toast.success("Projekt erfolgreich gelöscht");
    },
    onError: (err) => {
      toast.error(`Fehler beim Löschen: ${err.message}`);
    },
  });

  const statuses = useMemo(() => {
    const s = new Set(projects.map((p) => p.status));
    // Split BD/DD into separate BD and DD entries for filtering
    const statusList = Array.from(s);
    const idx = statusList.indexOf("BD/DD");
    if (idx !== -1) {
      statusList.splice(idx, 1);
      if (!statusList.includes("BD")) statusList.push("BD");
      if (!statusList.includes("DD")) statusList.push("DD");
    }
    return ["alle", ...statusList];
  }, [projects]);

  const filtered = useMemo(() => {
    let result = [...projects];
    if (statusFilter !== "alle") {
      if (statusFilter === "BD") {
        result = result.filter((p) => p.status === "BD" || p.status === "BD/DD");
      } else if (statusFilter === "DD") {
        result = result.filter((p) => p.status === "DD" || p.status === "BD/DD");
      } else {
        result = result.filter((p) => p.status === statusFilter);
      }
    }
    if (search) {
      const q = search.toLowerCase();
      result = result.filter(
        (p) =>
          p.kunde.toLowerCase().includes(q) ||
          p.projekt.toLowerCase().includes(q) ||
          (p.mitarbeiter || "").toLowerCase().includes(q) ||
          (p.mentorSupport || "").toLowerCase().includes(q) ||
          (p.ktmLead || "").toLowerCase().includes(q)
      );
    }
    result.sort((a, b) => {
      const aVal = a[sortField] ?? 0;
      const bVal = b[sortField] ?? 0;
      if (typeof aVal === "string" && typeof bVal === "string") {
        return sortDir === "asc" ? aVal.localeCompare(bVal) : bVal.localeCompare(aVal);
      }
      return sortDir === "asc" ? Number(aVal) - Number(bVal) : Number(bVal) - Number(aVal);
    });
    return result;
  }, [projects, statusFilter, search, sortField, sortDir]);

  const toggleSort = (field: keyof DbProject) => {
    if (sortField === field) {
      setSortDir(sortDir === "asc" ? "desc" : "asc");
    } else {
      setSortField(field);
      setSortDir("desc");
    }
  };

  const startEdit = useCallback((p: DbProject) => {
    setEditingId(p.id);
    setEditData({
      kunde: p.kunde,
      projekt: p.projekt,
      status: p.status,
      geplanterStart: p.geplanterStart || "",
      bestellung: p.bestellung,
      mentorSupport: p.mentorSupport || "",
      ktmLead: p.ktmLead || "",
      mitarbeiter: p.mitarbeiter || "",
      qaa: p.qaa || "",
      stunden: p.stunden,
      wahrscheinlichkeit: p.wahrscheinlichkeit,
      bemerkung: p.bemerkung || "",
    });
    setExpandedId(null);
  }, []);

  const saveEdit = useCallback(() => {
    if (!editingId) return;
    updateMutation.mutate({ id: editingId, data: editData });
  }, [editingId, editData, updateMutation]);

  const cancelEdit = useCallback(() => {
    setEditingId(null);
  }, []);

  const handleCreate = useCallback(() => {
    if (!newData.kunde || !newData.projekt) {
      toast.error("Kunde und Projekt sind Pflichtfelder");
      return;
    }
    createMutation.mutate(newData);
  }, [newData, createMutation]);

  const handleDelete = useCallback(
    (id: number) => {
      if (window.confirm("Möchten Sie dieses Projekt wirklich löschen?")) {
        deleteMutation.mutate({ id });
      }
    },
    [deleteMutation]
  );

  const SortIcon = ({ field }: { field: keyof DbProject }) => {
    if (sortField !== field) return null;
    return sortDir === "asc" ? <ChevronUp size={14} /> : <ChevronDown size={14} />;
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="animate-spin text-primary" size={32} />
        <span className="ml-3 text-muted-foreground">Projekte werden geladen...</span>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5 }}
    >
      {/* Filters + Add Button */}
      <div className="flex flex-col sm:flex-row gap-4 mb-6">
        <div className="relative flex-1">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <input
            type="text"
            placeholder="Suche nach Kunde, Projekt, Mitarbeiter..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 rounded-lg border border-border bg-card text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-colors"
          />
        </div>
        <div className="flex items-center gap-2">
          <Filter size={16} className="text-muted-foreground" />
          <div className="flex gap-1.5 flex-wrap">
            {statuses.map((s) => (
              <button
                key={s}
                onClick={() => setStatusFilter(s)}
                className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${
                  statusFilter === s
                    ? "bg-primary text-primary-foreground"
                    : "bg-secondary text-secondary-foreground hover:bg-accent"
                }`}
              >
                {s === "alle" ? "Alle" : s}
              </button>
            ))}
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={handleCsvExport}
            className="flex items-center gap-2 px-3 py-2.5 rounded-lg border border-border bg-card text-sm font-medium hover:bg-accent transition-colors"
            title="CSV exportieren"
          >
            <Download size={16} />
            <span className="hidden sm:inline">Export</span>
          </button>
          {isAuthenticated && (
            <>
              <button
                onClick={handleCsvImport}
                disabled={csvImportMutation.isPending}
                className="flex items-center gap-2 px-3 py-2.5 rounded-lg border border-border bg-card text-sm font-medium hover:bg-accent transition-colors disabled:opacity-50"
                title="CSV importieren"
              >
                {csvImportMutation.isPending ? <Loader2 size={16} className="animate-spin" /> : <Upload size={16} />}
                <span className="hidden sm:inline">Import</span>
              </button>
              <button
                onClick={() => setShowNewForm(!showNewForm)}
                className="flex items-center gap-2 px-4 py-2.5 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors"
              >
                <Plus size={16} />
                Neues Projekt
              </button>
            </>
          )}
        </div>
      </div>

      {/* New Project Form */}
      <AnimatePresence>
        {showNewForm && isAuthenticated && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden mb-6"
          >
            <div className="bg-card border-2 border-primary/20 rounded-xl p-6">
              <h3 className="text-lg font-semibold text-foreground mb-4">Neues Projekt anlegen</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                <EditField label="Kunde *" value={newData.kunde} onChange={(v) => setNewData({ ...newData, kunde: v })} />
                <EditField label="Projekt *" value={newData.projekt} onChange={(v) => setNewData({ ...newData, projekt: v })} />
                <div>
                  <label className="text-xs text-muted-foreground uppercase tracking-wider mb-1 block">Status</label>
                  <select
                    value={newData.status}
                    onChange={(e) => setNewData({ ...newData, status: e.target.value as DbProject["status"] })}
                    className="w-full px-3 py-2 rounded-lg border border-border bg-background text-sm focus:outline-none focus:ring-2 focus:ring-primary/20"
                  >
                    {statusOptions.map((s) => (
                      <option key={s} value={s}>{s}</option>
                    ))}
                  </select>
                </div>
                <EditField label="Geplanter Start" value={newData.geplanterStart} onChange={(v) => setNewData({ ...newData, geplanterStart: v })} />
                <div>
                  <label className="text-xs text-muted-foreground uppercase tracking-wider mb-1 block">Bestellung</label>
                  <select
                    value={newData.bestellung}
                    onChange={(e) => setNewData({ ...newData, bestellung: Number(e.target.value) })}
                    className="w-full px-3 py-2 rounded-lg border border-border bg-background text-sm focus:outline-none focus:ring-2 focus:ring-primary/20"
                  >
                    <option value={1}>Ja</option>
                    <option value={0}>Nein</option>
                  </select>
                </div>
                <EditField label="Mentor/Support" value={newData.mentorSupport} onChange={(v) => setNewData({ ...newData, mentorSupport: v })} />
                <EditField label="KTM Lead" value={newData.ktmLead} onChange={(v) => setNewData({ ...newData, ktmLead: v })} />
                <EditField label="Mitarbeiter" value={newData.mitarbeiter} onChange={(v) => setNewData({ ...newData, mitarbeiter: v })} />
                <EditField label="QAA" value={newData.qaa} onChange={(v) => setNewData({ ...newData, qaa: v })} />
                <div>
                  <label className="text-xs text-muted-foreground uppercase tracking-wider mb-1 block">Stunden</label>
                  <input
                    type="number"
                    value={newData.stunden ?? ""}
                    onChange={(e) => setNewData({ ...newData, stunden: e.target.value ? Number(e.target.value) : null })}
                    className="w-full px-3 py-2 rounded-lg border border-border bg-background text-sm focus:outline-none focus:ring-2 focus:ring-primary/20"
                    placeholder="z.B. 150"
                  />
                </div>
                <div>
                  <label className="text-xs text-muted-foreground uppercase tracking-wider mb-1 block">
                    Wahrscheinlichkeit: {newData.wahrscheinlichkeit}%
                  </label>
                  <input
                    type="range"
                    min="0"
                    max="100"
                    step="10"
                    value={newData.wahrscheinlichkeit}
                    onChange={(e) => setNewData({ ...newData, wahrscheinlichkeit: Number(e.target.value) })}
                    className="w-full accent-primary"
                  />
                </div>
                <EditField label="Bemerkung" value={newData.bemerkung} onChange={(v) => setNewData({ ...newData, bemerkung: v })} />
              </div>
              <div className="flex gap-3 mt-6">
                <button
                  onClick={handleCreate}
                  disabled={createMutation.isPending}
                  className="flex items-center gap-2 px-5 py-2.5 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors disabled:opacity-50"
                >
                  {createMutation.isPending ? <Loader2 size={16} className="animate-spin" /> : <Save size={16} />}
                  Erstellen
                </button>
                <button
                  onClick={() => { setShowNewForm(false); setNewData({ ...emptyProject }); }}
                  className="flex items-center gap-2 px-5 py-2.5 rounded-lg border border-border text-sm font-medium hover:bg-muted transition-colors"
                >
                  <X size={16} />
                  Abbrechen
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Table */}
      <div className="overflow-x-auto rounded-xl border border-border bg-card">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-border bg-muted/50">
              <th className="text-left px-4 py-3 font-medium text-muted-foreground cursor-pointer hover:text-foreground" onClick={() => toggleSort("kunde")}>
                <span className="flex items-center gap-1">Kunde <SortIcon field="kunde" /></span>
              </th>
              <th className="text-left px-4 py-3 font-medium text-muted-foreground cursor-pointer hover:text-foreground" onClick={() => toggleSort("projekt")}>
                <span className="flex items-center gap-1">Projekt <SortIcon field="projekt" /></span>
              </th>
              <th className="text-left px-4 py-3 font-medium text-muted-foreground">Status</th>
              <th className="text-left px-4 py-3 font-medium text-muted-foreground">Bestellung</th>
              <th className="text-left px-4 py-3 font-medium text-muted-foreground hidden lg:table-cell">Mentor/Support</th>
              <th className="text-left px-4 py-3 font-medium text-muted-foreground hidden lg:table-cell">KTM Lead</th>
              <th className="text-left px-4 py-3 font-medium text-muted-foreground hidden xl:table-cell">Mitarbeiter</th>
              <th className="text-left px-4 py-3 font-medium text-muted-foreground cursor-pointer hover:text-foreground" onClick={() => toggleSort("wahrscheinlichkeit")}>
                <span className="flex items-center gap-1">Wahrsch. <SortIcon field="wahrscheinlichkeit" /></span>
              </th>
              <th className="text-left px-4 py-3 font-medium text-muted-foreground w-24">Aktionen</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((p) =>
              editingId === p.id ? (
                <tr key={p.id} className="border-b border-primary/20 bg-primary/5">
                  <td className="px-3 py-2">
                    <input
                      value={editData.kunde}
                      onChange={(e) => setEditData({ ...editData, kunde: e.target.value })}
                      className="w-full px-2 py-1.5 rounded border border-border bg-background text-sm focus:outline-none focus:ring-2 focus:ring-primary/20"
                    />
                  </td>
                  <td className="px-3 py-2">
                    <input
                      value={editData.projekt}
                      onChange={(e) => setEditData({ ...editData, projekt: e.target.value })}
                      className="w-full px-2 py-1.5 rounded border border-border bg-background text-sm focus:outline-none focus:ring-2 focus:ring-primary/20"
                    />
                  </td>
                  <td className="px-3 py-2">
                    <select
                      value={editData.status}
                      onChange={(e) => setEditData({ ...editData, status: e.target.value as DbProject["status"] })}
                      className="w-full px-2 py-1.5 rounded border border-border bg-background text-sm focus:outline-none focus:ring-2 focus:ring-primary/20"
                    >
                      {statusOptions.map((s) => (
                        <option key={s} value={s}>{s}</option>
                      ))}
                    </select>
                  </td>
                  <td className="px-3 py-2">
                    <select
                      value={editData.bestellung}
                      onChange={(e) => setEditData({ ...editData, bestellung: Number(e.target.value) })}
                      className="w-full px-2 py-1.5 rounded border border-border bg-background text-sm focus:outline-none focus:ring-2 focus:ring-primary/20"
                    >
                      <option value={1}>Ja</option>
                      <option value={0}>Nein</option>
                    </select>
                  </td>
                  <td className="px-3 py-2 hidden lg:table-cell">
                    <input
                      value={editData.mentorSupport}
                      onChange={(e) => setEditData({ ...editData, mentorSupport: e.target.value })}
                      className="w-full px-2 py-1.5 rounded border border-border bg-background text-sm focus:outline-none focus:ring-2 focus:ring-primary/20"
                    />
                  </td>
                  <td className="px-3 py-2 hidden lg:table-cell">
                    <input
                      value={editData.ktmLead}
                      onChange={(e) => setEditData({ ...editData, ktmLead: e.target.value })}
                      className="w-full px-2 py-1.5 rounded border border-border bg-background text-sm focus:outline-none focus:ring-2 focus:ring-primary/20"
                    />
                  </td>
                  <td className="px-3 py-2 hidden xl:table-cell">
                    <input
                      value={editData.mitarbeiter}
                      onChange={(e) => setEditData({ ...editData, mitarbeiter: e.target.value })}
                      className="w-full px-2 py-1.5 rounded border border-border bg-background text-sm focus:outline-none focus:ring-2 focus:ring-primary/20"
                    />
                  </td>
                  <td className="px-3 py-2">
                    <div className="flex items-center gap-1">
                      <input
                        type="range"
                        min="0"
                        max="100"
                        step="10"
                        value={editData.wahrscheinlichkeit}
                        onChange={(e) => setEditData({ ...editData, wahrscheinlichkeit: Number(e.target.value) })}
                        className="w-12 accent-primary"
                      />
                      <span className="text-xs font-medium w-8">{editData.wahrscheinlichkeit}%</span>
                    </div>
                  </td>
                  <td className="px-3 py-2">
                    <div className="flex items-center gap-1">
                      <button
                        onClick={saveEdit}
                        disabled={updateMutation.isPending}
                        className="p-1.5 rounded-md bg-emerald-500 text-white hover:bg-emerald-600 transition-colors disabled:opacity-50"
                        title="Speichern"
                      >
                        {updateMutation.isPending ? <Loader2 size={14} className="animate-spin" /> : <Save size={14} />}
                      </button>
                      <button
                        onClick={cancelEdit}
                        className="p-1.5 rounded-md bg-muted text-muted-foreground hover:bg-accent transition-colors"
                        title="Abbrechen"
                      >
                        <X size={14} />
                      </button>
                    </div>
                  </td>
                </tr>
              ) : (
                <tr
                  key={p.id}
                  className="border-b border-border/50 hover:bg-muted/30 transition-colors cursor-pointer group"
                  onClick={() => setExpandedId(expandedId === p.id ? null : p.id)}
                >
                  <td className="px-4 py-3 font-medium text-foreground">{p.kunde}</td>
                  <td className="px-4 py-3">
                    <span className="font-mono text-xs bg-muted px-2 py-1 rounded">{p.projekt}</span>
                  </td>
                  <td className="px-4 py-3">
                    <span className={`text-xs font-medium px-2.5 py-1 rounded-full ${statusColors[p.status] || "bg-gray-100 text-gray-800"}`}>
                      {p.status}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    {p.bestellung === 1 ? (
                      <span className="w-5 h-5 rounded-full bg-emerald-500 inline-flex items-center justify-center">
                        <svg width="12" height="12" viewBox="0 0 12 12" fill="none"><path d="M2.5 6L5 8.5L9.5 3.5" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" /></svg>
                      </span>
                    ) : (
                      <span className="w-5 h-5 rounded-full bg-muted inline-flex items-center justify-center">
                        <svg width="12" height="12" viewBox="0 0 12 12" fill="none"><path d="M3 9L9 3M3 3L9 9" stroke="#9ca3af" strokeWidth="1.5" strokeLinecap="round" /></svg>
                      </span>
                    )}
                  </td>
                  <td className="px-4 py-3 text-muted-foreground hidden lg:table-cell">{p.mentorSupport || "\u2014"}</td>
                  <td className="px-4 py-3 text-muted-foreground hidden lg:table-cell">{p.ktmLead || "\u2014"}</td>
                  <td className="px-4 py-3 text-muted-foreground hidden xl:table-cell max-w-[200px] truncate">{p.mitarbeiter || "\u2014"}</td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <div className="w-16 h-2 rounded-full bg-muted overflow-hidden">
                        <div className={`h-full rounded-full ${probColors(p.wahrscheinlichkeit)}`} style={{ width: `${p.wahrscheinlichkeit}%` }} />
                      </div>
                      <span className="text-xs font-medium text-foreground w-8">{p.wahrscheinlichkeit}%</span>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    {isAuthenticated && (
                      <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button
                          onClick={(e) => { e.stopPropagation(); startEdit(p); }}
                          className="p-1.5 rounded-md hover:bg-primary/10 text-primary transition-colors"
                          title="Bearbeiten"
                        >
                          <Pencil size={14} />
                        </button>
                        <button
                          onClick={(e) => { e.stopPropagation(); handleDelete(p.id); }}
                          className="p-1.5 rounded-md hover:bg-red-100 text-red-500 transition-colors"
                          title="Löschen"
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    )}
                  </td>
                </tr>
              )
            )}
          </tbody>
        </table>
        {filtered.length === 0 && (
          <div className="text-center py-12 text-muted-foreground">
            Keine Projekte gefunden.
          </div>
        )}
      </div>

      {/* Expanded detail */}
      <AnimatePresence>
        {expandedId && editingId !== expandedId && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="mt-4 bg-card border border-border rounded-xl p-6"
          >
            {(() => {
              const p = projects.find((pr) => pr.id === expandedId);
              if (!p) return null;
              return (
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-semibold text-foreground">
                      {p.kunde} - {p.projekt}
                    </h3>
                    {isAuthenticated && (
                      <div className="flex gap-2">
                        <button
                          onClick={() => startEdit(p)}
                          className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors"
                        >
                          <Pencil size={14} />
                          Bearbeiten
                        </button>
                        <button
                          onClick={() => handleDelete(p.id)}
                          className="flex items-center gap-2 px-3 py-1.5 rounded-lg border border-red-200 text-red-600 text-sm font-medium hover:bg-red-50 transition-colors"
                        >
                          <Trash2 size={14} />
                          Löschen
                        </button>
                      </div>
                    )}
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    <DetailField label="Kunde" value={p.kunde} />
                    <DetailField label="Projekt" value={p.projekt} />
                    <DetailField label="Status" value={p.status} />
                    <DetailField label="Geplanter Start" value={p.geplanterStart || "Nicht festgelegt"} />
                    <DetailField label="Bestellung" value={p.bestellung === 1 ? "Ja" : "Nein"} />
                    <DetailField label="Mentor/Support" value={p.mentorSupport || "\u2014"} />
                    <DetailField label="KTM Lead" value={p.ktmLead || "\u2014"} />
                    <DetailField label="Mitarbeiter" value={p.mitarbeiter || "\u2014"} />
                    <DetailField label="QAA" value={p.qaa || "\u2014"} />
                    <DetailField label="Stunden" value={p.stunden ? `${p.stunden} h` : "\u2014"} />
                    <DetailField label="Wahrscheinlichkeit" value={`${p.wahrscheinlichkeit}%`} />
                    <DetailField label="Bemerkung" value={p.bemerkung || "\u2014"} />
                  </div>
                </div>
              );
            })()}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Edit expanded form for hidden fields */}
      <AnimatePresence>
        {editingId && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="mt-4 bg-card border-2 border-primary/20 rounded-xl p-6"
          >
            <h3 className="text-lg font-semibold text-foreground mb-4">Weitere Felder bearbeiten</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              <EditField label="Geplanter Start" value={editData.geplanterStart} onChange={(v) => setEditData({ ...editData, geplanterStart: v })} />
              <EditField label="QAA" value={editData.qaa} onChange={(v) => setEditData({ ...editData, qaa: v })} />
              <div>
                <label className="text-xs text-muted-foreground uppercase tracking-wider mb-1 block">Stunden</label>
                <input
                  type="number"
                  value={editData.stunden ?? ""}
                  onChange={(e) => setEditData({ ...editData, stunden: e.target.value ? Number(e.target.value) : null })}
                  className="w-full px-3 py-2 rounded-lg border border-border bg-background text-sm focus:outline-none focus:ring-2 focus:ring-primary/20"
                  placeholder="z.B. 150"
                />
              </div>
              <EditField label="Bemerkung" value={editData.bemerkung} onChange={(v) => setEditData({ ...editData, bemerkung: v })} />
            </div>
            <div className="flex gap-3 mt-4">
              <button
                onClick={saveEdit}
                disabled={updateMutation.isPending}
                className="flex items-center gap-2 px-5 py-2.5 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors disabled:opacity-50"
              >
                {updateMutation.isPending ? <Loader2 size={16} className="animate-spin" /> : <Save size={16} />}
                Alle Änderungen speichern
              </button>
              <button
                onClick={cancelEdit}
                className="flex items-center gap-2 px-5 py-2.5 rounded-lg border border-border text-sm font-medium hover:bg-muted transition-colors"
              >
                <X size={16} />
                Abbrechen
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <p className="text-xs text-muted-foreground mt-4">
        {filtered.length} von {projects.length} Projekten angezeigt. Klicken Sie auf eine Zeile für Details{isAuthenticated ? ", oder auf das Stift-Symbol zum Bearbeiten" : ". Melden Sie sich an, um Projekte zu bearbeiten"}.
      </p>
    </motion.div>
  );
}

function EditField({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
  return (
    <div>
      <label className="text-xs text-muted-foreground uppercase tracking-wider mb-1 block">{label}</label>
      <input
        type="text"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full px-3 py-2 rounded-lg border border-border bg-background text-sm focus:outline-none focus:ring-2 focus:ring-primary/20"
      />
    </div>
  );
}

function DetailField({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">{label}</p>
      <p className="text-sm text-foreground font-medium">{value}</p>
    </div>
  );
}
