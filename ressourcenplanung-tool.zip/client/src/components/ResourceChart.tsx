import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";
import { Users, UserCheck, Briefcase, Shield, Award } from "lucide-react";

type RoleKey = "alle" | "mentor" | "ktmLead" | "mitarbeiter" | "qaa";

interface RoleFilter {
  key: RoleKey;
  label: string;
  icon: React.ReactNode;
  color: string;
}

const roleFilters: RoleFilter[] = [
  { key: "alle", label: "Alle Rollen", icon: <Users className="w-3.5 h-3.5" />, color: "#005CA9" },
  { key: "mentor", label: "Mentor/Support", icon: <UserCheck className="w-3.5 h-3.5" />, color: "#0369a1" },
  { key: "ktmLead", label: "KTM Lead", icon: <Briefcase className="w-3.5 h-3.5" />, color: "#1d4ed8" },
  { key: "mitarbeiter", label: "Mitarbeiter", icon: <Shield className="w-3.5 h-3.5" />, color: "#4f46e5" },
  { key: "qaa", label: "QAA", icon: <Award className="w-3.5 h-3.5" />, color: "#7c3aed" },
];

interface Props {
  stats: {
    topResources: [string, number][];
    resourcesByRole: {
      alle: [string, number][];
      mentor: [string, number][];
      ktmLead: [string, number][];
      mitarbeiter: [string, number][];
      qaa: [string, number][];
    };
    kundenVerteilung: { name: string; value: number }[];
  };
}

export function ResourceChart({ stats }: Props) {
  const [activeRole, setActiveRole] = useState<RoleKey>("alle");

  const activeFilter = roleFilters.find((f) => f.key === activeRole)!;
  const activeData = stats.resourcesByRole[activeRole];

  const chartData = activeData.map(([name, count]) => ({
    name: name.length > 20 ? name.substring(0, 18) + "..." : name,
    fullName: name,
    projekte: count,
  }));

  // Dynamische Höhe: 36px pro Mitarbeiter, mindestens 200px
  const chartHeight = Math.max(200, chartData.length * 36);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay: 0.1 }}
      className="bg-white border border-border rounded-lg p-6 flex flex-col"
    >
      <h3 className="font-serif text-2xl text-foreground font-bold mb-2">
        Ressourcenauslastung
      </h3>
      <p className="text-muted-foreground text-sm mb-4">
        Projektzuweisungen pro Teammitglied nach Rolle filtern
      </p>

      {/* Rollenfilter-Buttons */}
      <div className="flex flex-wrap gap-2 mb-6">
        {roleFilters.map((filter) => {
          const isActive = activeRole === filter.key;
          const count = stats.resourcesByRole[filter.key].length;
          return (
            <button
              key={filter.key}
              onClick={() => setActiveRole(filter.key)}
              className={`
                inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium
                transition-all duration-200 border
                ${isActive
                  ? "text-white border-transparent shadow-sm"
                  : "bg-white text-muted-foreground border-border hover:border-[#005CA9]/30 hover:text-[#005CA9]"
                }
              `}
              style={isActive ? { backgroundColor: filter.color } : undefined}
            >
              {filter.icon}
              {filter.label}
              <span
                className={`
                  ml-0.5 px-1.5 py-0.5 rounded-full text-[10px] font-bold
                  ${isActive ? "bg-white/20 text-white" : "bg-gray-100 text-gray-500"}
                `}
              >
                {count}
              </span>
            </button>
          );
        })}
      </div>

      {/* Aktiver Filter Info */}
      <div className="flex items-center gap-2 mb-4 px-3 py-2 rounded-md bg-[#f0f4f8]">
        <div
          className="w-2 h-2 rounded-full"
          style={{ backgroundColor: activeFilter.color }}
        />
        <span className="text-xs font-medium text-foreground">
          {activeFilter.label}
        </span>
        <span className="text-xs text-muted-foreground">
          — {chartData.length} {chartData.length === 1 ? "Person" : "Personen"} zugewiesen
        </span>
      </div>

      {/* Bar Chart - dynamische Höhe */}
      <AnimatePresence mode="wait">
        <motion.div
          key={activeRole}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          transition={{ duration: 0.3 }}
        >
          {chartData.length > 0 ? (
            <div style={{ height: `${chartHeight}px` }} className="mb-8">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData} layout="vertical" margin={{ left: 10, right: 20 }}>
                  <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#e2e8f0" />
                  <XAxis type="number" tick={{ fontSize: 12, fill: "#656565" }} allowDecimals={false} />
                  <YAxis
                    type="category"
                    dataKey="name"
                    tick={{ fontSize: 11, fill: "#656565" }}
                    width={130}
                    interval={0}
                  />
                  <Tooltip
                    contentStyle={{
                      background: "white",
                      border: "1px solid #e2e8f0",
                      borderRadius: "6px",
                      fontSize: "13px",
                    }}
                    formatter={(value: number, _name: string, props: any) => [
                      `${value} ${value === 1 ? "Projekt" : "Projekte"}`,
                      props.payload.fullName,
                    ]}
                  />
                  <Bar
                    dataKey="projekte"
                    fill={activeFilter.color}
                    radius={[0, 4, 4, 0]}
                    barSize={18}
                  />
                </BarChart>
              </ResponsiveContainer>
            </div>
          ) : (
            <div className="flex items-center justify-center h-48 mb-8 text-muted-foreground text-sm">
              Keine Zuweisungen in dieser Rolle vorhanden.
            </div>
          )}
        </motion.div>
      </AnimatePresence>

      {/* Kunden-Verteilung */}
      <div className="border-t border-border pt-6">
        <h4 className="text-sm font-semibold text-foreground mb-4">
          Projekte pro Kunde
        </h4>
        <div className="space-y-2.5">
          {stats.kundenVerteilung.map((item, i) => (
            <div key={item.name} className="flex items-center gap-3">
              <span className="text-xs text-muted-foreground w-32 truncate">{item.name}</span>
              <div className="flex-1 h-2.5 rounded-full bg-[#f0f4f8] overflow-hidden">
                <motion.div
                  initial={{ width: 0 }}
                  whileInView={{ width: `${(item.value / stats.kundenVerteilung[0].value) * 100}%` }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.05, duration: 0.5 }}
                  className="h-full rounded-full bg-[#005CA9]"
                />
              </div>
              <span className="text-xs font-semibold text-foreground w-6 text-right">{item.value}</span>
            </div>
          ))}
        </div>
      </div>
    </motion.div>
  );
}
