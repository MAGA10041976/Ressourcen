import { motion } from "framer-motion";
import {
  FolderKanban,
  PlayCircle,
  FileText,
  ClipboardCheck,
  TrendingUp,
  Users,
} from "lucide-react";

interface StatsProps {
  stats: {
    total: number;
    laufend: number;
    angebote: number;
    inPlanung: number;
    mitBestellung: number;
    ohneBestellung: number;
    kunden: number;
    mitarbeiter: number;
    probDistribution: { hoch: number; mittel: number; niedrig: number };
  };
}

export function StatsOverview({ stats }: StatsProps) {
  const cards = [
    { icon: <FolderKanban size={22} />, value: stats.total, label: "Projekte gesamt", color: "bg-[#005CA9]/10 text-[#005CA9]" },
    { icon: <PlayCircle size={22} />, value: stats.laufend, label: "Laufende Projekte", color: "bg-[#005CA9]/10 text-[#005CA9]" },
    { icon: <FileText size={22} />, value: stats.angebote, label: "Offene Angebote", color: "bg-[#07284A]/10 text-[#07284A]" },
    { icon: <ClipboardCheck size={22} />, value: stats.inPlanung, label: "In Planung (BD/DD/CD)", color: "bg-[#005CA9]/10 text-[#005CA9]" },
    { icon: <TrendingUp size={22} />, value: stats.mitBestellung, label: "Mit Bestellung", color: "bg-[#005CA9]/10 text-[#005CA9]" },
    { icon: <Users size={22} />, value: stats.mitarbeiter, label: "Teammitglieder", color: "bg-[#07284A]/10 text-[#07284A]" },
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
      {cards.map((card, i) => (
        <motion.div
          key={card.label}
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: i * 0.08, duration: 0.5 }}
          className="bg-white border border-border rounded-lg p-5 hover:shadow-md hover:border-[#005CA9]/30 transition-all"
        >
          <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${card.color} mb-4`}>
            {card.icon}
          </div>
          <p className="font-serif text-3xl text-foreground font-bold">{card.value}</p>
          <p className="text-muted-foreground text-sm mt-1 leading-snug">{card.label}</p>
        </motion.div>
      ))}
    </div>
  );
}
