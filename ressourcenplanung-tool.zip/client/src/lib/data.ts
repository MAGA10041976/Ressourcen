// DB Project type matches the drizzle schema
export interface DbProject {
  id: number;
  kunde: string;
  projekt: string;
  status: "Angebot" | "BD" | "BD/DD" | "CD" | "DD" | "läuft";
  geplanterStart: string | null;
  bestellung: number;
  mentorSupport: string | null;
  ktmLead: string | null;
  mitarbeiter: string | null;
  qaa: string | null;
  stunden: number | null;
  wahrscheinlichkeit: number;
  bemerkung: string | null;
  createdAt: Date;
  updatedAt: Date;
}

// Seed data for initial database population
export const seedProjects: Omit<DbProject, "id" | "createdAt" | "updatedAt">[] = [
  { kunde: "BI", projekt: "BI-UK", status: "BD", geplanterStart: "", bestellung: 1, mentorSupport: "John Nichols", ktmLead: "Diego Castillo", mitarbeiter: "Peter B. / Gerald Thermer", qaa: "Dominik Emerich", stunden: null, wahrscheinlichkeit: 100, bemerkung: "Schulung CopaData FlexLink" },
  { kunde: "CSL USA", projekt: "IGZAP", status: "CD", geplanterStart: "", bestellung: 1, mentorSupport: "", ktmLead: "", mitarbeiter: "Laura Brus", qaa: "", stunden: 150, wahrscheinlichkeit: 80, bemerkung: "" },
  { kunde: "CSL USA", projekt: "IGZAP", status: "BD/DD", geplanterStart: "", bestellung: 0, mentorSupport: "Laura Brus", ktmLead: "", mitarbeiter: "Diego Castillo Aaron", qaa: "", stunden: null, wahrscheinlichkeit: 50, bemerkung: "" },
  { kunde: "Daiichi", projekt: "FZDSE", status: "läuft", geplanterStart: "", bestellung: 1, mentorSupport: "Reinhart Meckel", ktmLead: "", mitarbeiter: "Patrizia Steinhoff", qaa: "Dominik Emerich", stunden: null, wahrscheinlichkeit: 100, bemerkung: "Indien + Dominik E." },
  { kunde: "GENMAR", projekt: "GENLU", status: "DD", geplanterStart: "", bestellung: 0, mentorSupport: "Josef Suchanek", ktmLead: "Jan Leinweber", mitarbeiter: "", qaa: "", stunden: null, wahrscheinlichkeit: 90, bemerkung: "" },
  { kunde: "ITM-Neufahrn", projekt: "ITM", status: "Angebot", geplanterStart: "", bestellung: 0, mentorSupport: "Reinhart Meckel", ktmLead: "Lydia Kreuter", mitarbeiter: "Matthias Kilger", qaa: "Lukas Holländer", stunden: null, wahrscheinlichkeit: 80, bemerkung: "" },
  { kunde: "Octapharma", projekt: "FIBRY", status: "Angebot", geplanterStart: "", bestellung: 0, mentorSupport: "Laura Brus", ktmLead: "Christian Trippler", mitarbeiter: "Max Müller", qaa: "Dominik Emerich", stunden: null, wahrscheinlichkeit: 90, bemerkung: "Indien + TBD / Gerald Thermer" },
  { kunde: "Octapharma", projekt: "FZOPS", status: "Angebot", geplanterStart: "", bestellung: 0, mentorSupport: "", ktmLead: "", mitarbeiter: "Patrizia Steinhoff", qaa: "Dominik Emerich", stunden: null, wahrscheinlichkeit: 90, bemerkung: "Indien + TBD" },
  { kunde: "Octapharma", projekt: "Freeze", status: "Angebot", geplanterStart: "", bestellung: 0, mentorSupport: "", ktmLead: "", mitarbeiter: "", qaa: "", stunden: null, wahrscheinlichkeit: 20, bemerkung: "PD oder BL" },
  { kunde: "Octapharma", projekt: "PANOC", status: "Angebot", geplanterStart: "", bestellung: 0, mentorSupport: "Laura Brus", ktmLead: "", mitarbeiter: "", qaa: "Dominik Emerich", stunden: null, wahrscheinlichkeit: 20, bemerkung: "" },
  { kunde: "Pfizer", projekt: "FZPG3", status: "läuft", geplanterStart: "", bestellung: 1, mentorSupport: "Reinhart Meckel", ktmLead: "Diego Castillo", mitarbeiter: "Sathish (IND)", qaa: "Dominik Emerich", stunden: null, wahrscheinlichkeit: 100, bemerkung: "Wechsel vollzogen" },
  { kunde: "ROCHE Penzberg", projekt: "BCM13", status: "läuft", geplanterStart: "", bestellung: 1, mentorSupport: "", ktmLead: "Verena Lindner", mitarbeiter: "Laura Brus, Jacob Holländer", qaa: "Dominik Emerich, Lukas Holländer", stunden: null, wahrscheinlichkeit: 100, bemerkung: "Ankit, Manoj (IND)" },
  { kunde: "ROCHE Penzberg", projekt: "DCPRP", status: "Angebot", geplanterStart: "", bestellung: 0, mentorSupport: "Laura Brus", ktmLead: "", mitarbeiter: "", qaa: "Dominik Emerich", stunden: null, wahrscheinlichkeit: 50, bemerkung: "" },
  { kunde: "SMS Canzler", projekt: "HYVRO", status: "Angebot", geplanterStart: "", bestellung: 0, mentorSupport: "Markus Garcia", ktmLead: "Dominik Emerich", mitarbeiter: "Felix Renner", qaa: "Lukas Holländer", stunden: null, wahrscheinlichkeit: 80, bemerkung: "" },
  { kunde: "SMS Canzler", projekt: "HYVA3", status: "Angebot", geplanterStart: "", bestellung: 0, mentorSupport: "Markus Garcia", ktmLead: "Dominik Emerich", mitarbeiter: "Felix Renner", qaa: "Lukas Holländer", stunden: null, wahrscheinlichkeit: 50, bemerkung: "" },
  { kunde: "STULLN Pharma", projekt: "STULN", status: "läuft", geplanterStart: "KW 10", bestellung: 1, mentorSupport: "", ktmLead: "Matej Deronja", mitarbeiter: "Reinhart Meckel", qaa: "Dominik Emerich", stunden: null, wahrscheinlichkeit: 100, bemerkung: "Reinhart umgeplant ab KW 10 - Reinhart KW 15 - Domi/Kathi KW 21- Kathi Ende KW 48" },
  { kunde: "TEVA", projekt: "XDTV3", status: "Angebot", geplanterStart: "", bestellung: 0, mentorSupport: "Verena Lindner", ktmLead: "Matthias Kilger", mitarbeiter: "", qaa: "Lukas Holländer", stunden: null, wahrscheinlichkeit: 70, bemerkung: "" },
  { kunde: "Octapharma", projekt: "OPXDE", status: "läuft", geplanterStart: "", bestellung: 1, mentorSupport: "", ktmLead: "Manuel Kämpf", mitarbeiter: "Christian Trippler", qaa: "", stunden: null, wahrscheinlichkeit: 100, bemerkung: "Indien + Alex Dentel" },
];

// Berechnete Statistiken - akzeptiert jetzt ein Array von Projekten
export function getStats(projectList: DbProject[] = []) {
  const total = projectList.length;
  const laufend = projectList.filter((p) => p.status === "läuft").length;
  const angebote = projectList.filter((p) => p.status === "Angebot").length;
  const inPlanung = projectList.filter((p) =>
    ["BD", "BD/DD", "CD", "DD"].includes(p.status)
  ).length;
  const mitBestellung = projectList.filter((p) => p.bestellung === 1).length;
  const ohneBestellung = total - mitBestellung;

  const kunden = new Set(projectList.map((p) => p.kunde)).size;

  const allPeople = new Set<string>();
  projectList.forEach((p) => {
    [p.mentorSupport, p.ktmLead, p.mitarbeiter, p.qaa].forEach((field) => {
      if (field) {
        field.split(/[,/]/).forEach((name) => {
          const trimmed = name.trim();
          if (trimmed && !trimmed.includes("TBD") && !trimmed.includes("IND")) {
            allPeople.add(trimmed);
          }
        });
      }
    });
  });

  const probDistribution = {
    hoch: projectList.filter((p) => p.wahrscheinlichkeit >= 90).length,
    mittel: projectList.filter(
      (p) => p.wahrscheinlichkeit >= 50 && p.wahrscheinlichkeit < 90
    ).length,
    niedrig: projectList.filter((p) => p.wahrscheinlichkeit < 50).length,
  };

  const gewichtetePipeline = projectList
    .filter((p) => p.status === "Angebot")
    .reduce((sum, p) => sum + p.wahrscheinlichkeit, 0);

  // Helper: Personen aus einem Feld extrahieren
  function extractNames(field: string | null): string[] {
    if (!field) return [];
    return field.split(/[,/]/).map(n => n.trim()).filter(
      n => n && n.length > 2 && !n.includes("TBD") && !n.includes("(IND)")
    );
  }

  // Alle Rollen aggregieren
  const resourceMap = new Map<string, number>();
  const mentorMap = new Map<string, number>();
  const ktmLeadMap = new Map<string, number>();
  const mitarbeiterMap = new Map<string, number>();
  const qaaMap = new Map<string, number>();

  projectList.forEach((p) => {
    // Alle Rollen zusammen
    [p.mentorSupport, p.ktmLead, p.mitarbeiter, p.qaa].forEach((field) => {
      extractNames(field).forEach((name) => {
        resourceMap.set(name, (resourceMap.get(name) || 0) + 1);
      });
    });
    // Einzelne Rollen
    extractNames(p.mentorSupport).forEach((name) => {
      mentorMap.set(name, (mentorMap.get(name) || 0) + 1);
    });
    extractNames(p.ktmLead).forEach((name) => {
      ktmLeadMap.set(name, (ktmLeadMap.get(name) || 0) + 1);
    });
    extractNames(p.mitarbeiter).forEach((name) => {
      mitarbeiterMap.set(name, (mitarbeiterMap.get(name) || 0) + 1);
    });
    extractNames(p.qaa).forEach((name) => {
      qaaMap.set(name, (qaaMap.get(name) || 0) + 1);
    });
  });

  const sortMap = (m: Map<string, number>) =>
    Array.from(m.entries()).sort((a, b) => b[1] - a[1]);

  const topResources = sortMap(resourceMap);
  const resourcesByRole = {
    alle: topResources,
    mentor: sortMap(mentorMap),
    ktmLead: sortMap(ktmLeadMap),
    mitarbeiter: sortMap(mitarbeiterMap),
    qaa: sortMap(qaaMap),
  };

  const statusVerteilung = [
    { name: "Läuft", value: laufend, color: "#0d9488" },
    { name: "Angebot", value: angebote, color: "#f97316" },
    { name: "BD/DD/CD", value: inPlanung, color: "#6366f1" },
  ];

  const kundenMap = new Map<string, number>();
  projectList.forEach((p) => {
    kundenMap.set(p.kunde, (kundenMap.get(p.kunde) || 0) + 1);
  });
  const kundenVerteilung = Array.from(kundenMap.entries())
    .map(([name, value]) => ({ name, value }))
    .sort((a, b) => b.value - a.value);

  return {
    total,
    laufend,
    angebote,
    inPlanung,
    mitBestellung,
    ohneBestellung,
    kunden,
    mitarbeiter: allPeople.size,
    probDistribution,
    gewichtetePipeline,
    topResources,
    resourcesByRole,
    statusVerteilung,
    kundenVerteilung,
  };
}

