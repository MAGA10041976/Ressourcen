import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import { DbProject, getStats } from "./data";

// ZETA Corporate Design Farben
const ZETA_BLUE = [0, 92, 169] as const; // #005CA9
const ZETA_DARK = [7, 40, 74] as const; // #07284A
const DARK = [7, 40, 74] as const; // Foreground
const GRAY = [101, 101, 101] as const;
const LIGHT_BG = [240, 244, 248] as const;
const WHITE = [255, 255, 255] as const;
const GREEN = [0, 92, 169] as const; // Use ZETA blue for high probability
const ORANGE = [59, 130, 246] as const; // Medium blue
const RED = [147, 197, 253] as const; // Light blue

function probColor(p: number): readonly [number, number, number] {
  if (p >= 90) return ZETA_BLUE;
  if (p >= 70) return [59, 130, 246] as const;
  if (p >= 50) return [96, 165, 250] as const;
  return [147, 197, 253] as const;
}

export function exportPDF(projectList: DbProject[]) {
  const doc = new jsPDF({ orientation: "landscape", unit: "mm", format: "a4" });
  const stats = getStats(projectList);
  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const margin = 15;
  const contentWidth = pageWidth - margin * 2;

  // ===== HELPER FUNCTIONS =====
  function addHeader(title: string, subtitle?: string) {
    // Top bar
    doc.setFillColor(...ZETA_BLUE);
    doc.rect(0, 0, pageWidth, 2, "F");

    // Title
    doc.setFont("helvetica", "bold");
    doc.setFontSize(22);
    doc.setTextColor(...DARK);
    doc.text(title, margin, 18);

    if (subtitle) {
      doc.setFont("helvetica", "normal");
      doc.setFontSize(10);
      doc.setTextColor(...GRAY);
      doc.text(subtitle, margin, 25);
    }

    // Right side: Date
    doc.setFont("helvetica", "normal");
    doc.setFontSize(8);
    doc.setTextColor(...GRAY);
    const dateStr = new Date().toLocaleDateString("de-DE", {
      day: "2-digit",
      month: "long",
      year: "numeric",
    });
    doc.text(`Stand: ${dateStr}`, pageWidth - margin, 18, { align: "right" });
    doc.text("Abteilung Automation", pageWidth - margin, 23, { align: "right" });
  }

  function addFooter(pageNum: number, totalPages: number) {
    doc.setDrawColor(220, 220, 220);
    doc.line(margin, pageHeight - 10, pageWidth - margin, pageHeight - 10);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(7);
    doc.setTextColor(...GRAY);
    doc.text("Ressourcenplanung & Forecast - Abteilung Automation", margin, pageHeight - 6);
    doc.text(`Seite ${pageNum} von ${totalPages}`, pageWidth - margin, pageHeight - 6, { align: "right" });
  }

  // ===== PAGE 1: Titelseite & Kennzahlen =====
  // Background
  doc.setFillColor(...LIGHT_BG);
  doc.rect(0, 0, pageWidth, pageHeight, "F");

  // Teal accent bar
  doc.setFillColor(...ZETA_BLUE);
  doc.rect(0, 0, pageWidth, 50, "F");

  // Title on teal
  doc.setFont("helvetica", "bold");
  doc.setFontSize(28);
  doc.setTextColor(...WHITE);
  doc.text("Ressourcenplanung & Forecast", margin, 25);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(12);
  doc.text("Abteilung Automation", margin, 35);

  // Date badge
  const dateStr = new Date().toLocaleDateString("de-DE", {
    day: "2-digit",
    month: "long",
    year: "numeric",
  });
  doc.setFontSize(10);
  doc.text(dateStr, pageWidth - margin, 35, { align: "right" });

  // KPI Cards
  let y = 65;
  const kpiData = [
    { label: "Projekte gesamt", value: stats.total.toString() },
    { label: "Laufende Projekte", value: stats.laufend.toString() },
    { label: "Offene Angebote", value: stats.angebote.toString() },
    { label: "In Planung (BD/DD/CD)", value: stats.inPlanung.toString() },
    { label: "Mit Bestellung", value: stats.mitBestellung.toString() },
    { label: "Kunden", value: stats.kunden.toString() },
    { label: "Teammitglieder", value: stats.mitarbeiter.toString() },
    { label: "Gew. Pipeline (%)", value: stats.gewichtetePipeline.toString() },
  ];

  doc.setFont("helvetica", "bold");
  doc.setFontSize(12);
  doc.setTextColor(...DARK);
  doc.text("Kennzahlen auf einen Blick", margin, y);
  y += 8;

  const cardW = (contentWidth - 3 * 6) / 4;
  const cardH = 28;
  kpiData.forEach((kpi, i) => {
    const col = i % 4;
    const row = Math.floor(i / 4);
    const x = margin + col * (cardW + 6);
    const cy = y + row * (cardH + 6);

    // Card background
    doc.setFillColor(...WHITE);
    doc.roundedRect(x, cy, cardW, cardH, 3, 3, "F");
    doc.setDrawColor(230, 230, 230);
    doc.roundedRect(x, cy, cardW, cardH, 3, 3, "S");

    // Value
    doc.setFont("helvetica", "bold");
    doc.setFontSize(20);
    doc.setTextColor(...ZETA_BLUE);
    doc.text(kpi.value, x + cardW / 2, cy + 14, { align: "center" });

    // Label
    doc.setFont("helvetica", "normal");
    doc.setFontSize(8);
    doc.setTextColor(...GRAY);
    doc.text(kpi.label, x + cardW / 2, cy + 22, { align: "center" });
  });

  y += 2 * (cardH + 6) + 10;

  // Wahrscheinlichkeitsverteilung
  doc.setFont("helvetica", "bold");
  doc.setFontSize(12);
  doc.setTextColor(...DARK);
  doc.text("Wahrscheinlichkeitsverteilung", margin, y);
  y += 8;

  const probData = [
    { label: "Hoch (>=90%)", value: stats.probDistribution.hoch, color: GREEN },
    { label: "Mittel (50-89%)", value: stats.probDistribution.mittel, color: ORANGE },
    { label: "Niedrig (<50%)", value: stats.probDistribution.niedrig, color: RED },
  ];

  probData.forEach((item, i) => {
    const barX = margin;
    const barY = y + i * 12;
    const barMaxW = contentWidth * 0.6;
    const barW = (item.value / stats.total) * barMaxW;

    // Label
    doc.setFont("helvetica", "normal");
    doc.setFontSize(9);
    doc.setTextColor(...DARK);
    doc.text(item.label, barX, barY + 4);

    // Bar background
    doc.setFillColor(235, 235, 235);
    doc.roundedRect(barX + 60, barY, barMaxW, 6, 2, 2, "F");

    // Bar fill
    doc.setFillColor(item.color[0], item.color[1], item.color[2]);
    if (barW > 4) {
      doc.roundedRect(barX + 60, barY, barW, 6, 2, 2, "F");
    }

    // Value
    doc.setFont("helvetica", "bold");
    doc.setFontSize(9);
    doc.text(`${item.value} Projekte`, barX + 62 + barMaxW, barY + 4);
  });

  y += 45;

  // Top Ressourcen
  doc.setFont("helvetica", "bold");
  doc.setFontSize(12);
  doc.setTextColor(...DARK);
  doc.text(`Ressourcenauslastung (${stats.topResources.length} Personen)`, margin, y);
  y += 4;

  autoTable(doc, {
    startY: y,
    margin: { left: margin, right: margin },
    head: [["Mitarbeiter", "Projekte"]],
    body: stats.topResources.map(([name, count]) => [name, count.toString()]),
    theme: "grid",
    headStyles: {
      fillColor: [...ZETA_BLUE],
      textColor: [...WHITE],
      fontSize: 8,
      fontStyle: "bold",
      cellPadding: 3,
    },
    bodyStyles: {
      fontSize: 8,
      cellPadding: 2.5,
      textColor: [...DARK],
    },
    alternateRowStyles: {
      fillColor: [248, 248, 245],
    },
    columnStyles: {
      0: { cellWidth: 80 },
      1: { cellWidth: 30, halign: "center" },
    },
    tableWidth: 120,
  });

  // ===== PAGE 2: Projekttabelle =====
  doc.addPage("landscape");
  addHeader("Projektübersicht", "Alle Projekte der Abteilung Automation");

  const tableBody = projectList.map((p: DbProject) => [
    p.kunde,
    p.projekt,
    p.status,
    p.bestellung === 1 ? "Ja" : "Nein",
    p.mentorSupport || "-",
    p.ktmLead || "-",
    p.mitarbeiter || "-",
    p.qaa || "-",
    p.stunden ? `${p.stunden}h` : "-",
    `${p.wahrscheinlichkeit}%`,
    p.bemerkung || "-",
  ]);

  autoTable(doc, {
    startY: 32,
    margin: { left: margin, right: margin },
    head: [
      [
        "Kunde",
        "Projekt",
        "Status",
        "Best.",
        "Mentor/Support",
        "KTM Lead",
        "Mitarbeiter",
        "QAA",
        "Std.",
        "Wahrsch.",
        "Bemerkung",
      ],
    ],
    body: tableBody,
    theme: "grid",
    headStyles: {
      fillColor: [...ZETA_BLUE],
      textColor: [...WHITE],
      fontSize: 7,
      fontStyle: "bold",
      cellPadding: 2,
    },
    bodyStyles: {
      fontSize: 6.5,
      cellPadding: 1.8,
      textColor: [...DARK],
      lineColor: [230, 230, 230],
    },
    alternateRowStyles: {
      fillColor: [248, 248, 245],
    },
    columnStyles: {
      0: { cellWidth: 28 },
      1: { cellWidth: 16 },
      2: { cellWidth: 16 },
      3: { cellWidth: 12, halign: "center" },
      4: { cellWidth: 30 },
      5: { cellWidth: 28 },
      6: { cellWidth: 36 },
      7: { cellWidth: 28 },
      8: { cellWidth: 12, halign: "center" },
      9: { cellWidth: 16, halign: "center" },
      10: { cellWidth: 45 },
    },
    didParseCell: (data) => {
      // Color-code status
      if (data.section === "body" && data.column.index === 2) {
        const val = data.cell.raw as string;
        if (val === "läuft") {
          data.cell.styles.textColor = [16, 185, 129];
          data.cell.styles.fontStyle = "bold";
        } else if (val === "Angebot") {
          data.cell.styles.textColor = [249, 115, 22];
          data.cell.styles.fontStyle = "bold";
        }
      }
      // Color-code probability
      if (data.section === "body" && data.column.index === 9) {
        const val = parseInt(data.cell.raw as string);
        if (val >= 90) data.cell.styles.textColor = [...GREEN];
        else if (val >= 70) data.cell.styles.textColor = [...ZETA_BLUE] as [number, number, number];
        else if (val >= 50) data.cell.styles.textColor = [...ORANGE];
        else data.cell.styles.textColor = [...RED];
        data.cell.styles.fontStyle = "bold";
      }
    },
  });

  // ===== Add footers to all pages =====
  const totalPages = doc.getNumberOfPages();
  for (let i = 1; i <= totalPages; i++) {
    doc.setPage(i);
    addFooter(i, totalPages);
  }

  // ===== Save =====
  doc.save("Ressourcenplanung_Entscheidungsvorlage.pdf");
}
