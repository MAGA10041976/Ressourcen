import { useAuth } from "@/_core/hooks/useAuth";
import { ShieldX, LogOut } from "lucide-react";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";

export default function AccessDenied() {
  const { user, logout } = useAuth();

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#07284A] to-[#005CA9] flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-8 text-center"
      >
        <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-6">
          <ShieldX className="w-8 h-8 text-red-600" />
        </div>

        <h1 className="text-2xl font-bold text-[#07284A] mb-3" style={{ fontFamily: "'Montserrat', sans-serif" }}>
          Zugang abgelehnt
        </h1>

        <p className="text-gray-600 mb-6 leading-relaxed">
          {user?.name ? `${user.name}, Ihr` : "Ihr"} Zugang zur Ressourcenplanung wurde leider abgelehnt.
          Bitte wenden Sie sich an den Administrator, wenn Sie der Meinung sind, dass dies ein Fehler ist.
        </p>

        <Button
          variant="ghost"
          onClick={() => logout()}
          className="text-gray-500 hover:text-red-600"
        >
          <LogOut className="w-4 h-4 mr-2" />
          Abmelden
        </Button>
      </motion.div>
    </div>
  );
}
