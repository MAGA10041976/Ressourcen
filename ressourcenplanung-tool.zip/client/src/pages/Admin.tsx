import { useState, useMemo } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import {
  ArrowLeft,
  Users,
  Shield,
  FolderKanban,
  Activity,
  FileText,
  Trash2,
  Loader2,
  CheckCircle2,
  XCircle,
  Clock,
  History,
  ChevronLeft,
  ChevronRight,
  UserCheck,
  UserX,
  MessageSquare,
  Send,
  Mail,
  MailOpen,
} from "lucide-react";
import { useLocation } from "wouter";

const LOGO_URL = "https://d2w4bkbcgs4yij.cloudfront.net/ressourcenplanung-tool/zeta-logo.png";

export default function Admin() {
  const { user, loading } = useAuth();
  const [, setLocation] = useLocation();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <Loader2 className="h-8 w-8 animate-spin text-[#005CA9]" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <img src={LOGO_URL} alt="ZETA Logo" className="h-10 mx-auto mb-4" />
            <CardTitle className="text-xl">Anmeldung erforderlich</CardTitle>
            <CardDescription>
              Bitte melden Sie sich an, um auf das Admin-Dashboard zuzugreifen.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button
              onClick={() => { window.location.href = getLoginUrl(); }}
              className="w-full bg-[#005CA9] hover:bg-[#004A87]"
            >
              Anmelden
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (user.role !== "admin") {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <Shield className="h-12 w-12 mx-auto text-red-500 mb-2" />
            <CardTitle className="text-xl">Zugriff verweigert</CardTitle>
            <CardDescription>
              Sie haben keine Administratorrechte. Bitte wenden Sie sich an einen Administrator.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button
              onClick={() => setLocation("/")}
              variant="outline"
              className="w-full"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Zur Startseite
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return <AdminDashboard />;
}

function AdminDashboard() {
  const [, setLocation] = useLocation();
  const { user, logout } = useAuth();
  const [activeTab, setActiveTab] = useState<"users" | "logs" | "messages">("users");

  const statsQuery = trpc.admin.stats.useQuery();
  const usersQuery = trpc.admin.users.list.useQuery();
  const utils = trpc.useUtils();

  const updateRoleMutation = trpc.admin.users.updateRole.useMutation({
    onSuccess: () => {
      utils.admin.users.list.invalidate();
      utils.admin.stats.invalidate();
      toast.success("Rolle erfolgreich aktualisiert");
    },
    onError: (err) => {
      toast.error("Fehler: " + err.message);
    },
  });

  const updateStatusMutation = trpc.admin.users.updateStatus.useMutation({
    onSuccess: (_, vars) => {
      utils.admin.users.list.invalidate();
      utils.admin.stats.invalidate();
      const statusText = vars.status === "approved" ? "freigeschaltet" : vars.status === "rejected" ? "abgelehnt" : "auf ausstehend gesetzt";
      toast.success(`Benutzer erfolgreich ${statusText}`);
    },
    onError: (err) => {
      toast.error("Fehler: " + err.message);
    },
  });

  const deleteUserMutation = trpc.admin.users.delete.useMutation({
    onSuccess: () => {
      utils.admin.users.list.invalidate();
      utils.admin.stats.invalidate();
      toast.success("Benutzer erfolgreich gelöscht");
    },
    onError: (err) => {
      toast.error("Fehler: " + err.message);
    },
  });

  const stats = statsQuery.data;
  const allUsers = usersQuery.data ?? [];
  const pendingUsers = allUsers.filter(u => u.status === "pending");

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-4">
              <img src={LOGO_URL} alt="ZETA Logo" className="h-8" />
              <div className="h-6 w-px bg-slate-300" />
              <h1 className="text-lg font-semibold text-slate-900 font-[Montserrat]">
                Admin-Dashboard
              </h1>
            </div>
            <div className="flex items-center gap-3">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setLocation("/")}
              >
                <ArrowLeft className="h-4 w-4 mr-1" />
                Zur Startseite
              </Button>
              <div className="flex items-center gap-2 px-3 py-1.5 bg-slate-100 rounded-full">
                <Shield className="h-4 w-4 text-[#005CA9]" />
                <span className="text-sm font-medium text-slate-700">
                  {user?.name || "Admin"}
                </span>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={logout}
                className="text-slate-500 hover:text-red-600"
              >
                Abmelden
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Statistik-Karten */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-4 mb-8">
          <StatCard
            icon={<Users className="h-5 w-5 text-[#005CA9]" />}
            label="Benutzer gesamt"
            value={stats?.totalUsers ?? 0}
            loading={statsQuery.isLoading}
          />
          <StatCard
            icon={<Clock className="h-5 w-5 text-amber-600" />}
            label="Ausstehend"
            value={stats?.pendingUsers ?? 0}
            loading={statsQuery.isLoading}
            highlight={!!stats?.pendingUsers && stats.pendingUsers > 0}
          />
          <StatCard
            icon={<CheckCircle2 className="h-5 w-5 text-emerald-600" />}
            label="Freigeschaltet"
            value={stats?.approvedUsers ?? 0}
            loading={statsQuery.isLoading}
          />
          <StatCard
            icon={<FolderKanban className="h-5 w-5 text-blue-600" />}
            label="Projekte gesamt"
            value={stats?.totalProjects ?? 0}
            loading={statsQuery.isLoading}
          />
          <StatCard
            icon={<History className="h-5 w-5 text-purple-600" />}
            label="Aktivitäten"
            value={stats?.totalActivityLogs ?? 0}
            loading={statsQuery.isLoading}
          />
          <StatCard
            icon={<MessageSquare className="h-5 w-5 text-teal-600" />}
            label="Nachrichten"
            value={stats?.totalMessages ?? 0}
            loading={statsQuery.isLoading}
          />
        </div>

        {/* Pending Users Alert */}
        {pendingUsers.length > 0 && (
          <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 mb-6 flex items-start gap-3">
            <Clock className="h-5 w-5 text-amber-600 mt-0.5 shrink-0" />
            <div>
              <p className="font-semibold text-amber-800">
                {pendingUsers.length} Benutzer warten auf Freischaltung
              </p>
              <p className="text-sm text-amber-700 mt-1">
                {pendingUsers.map(u => u.name || u.email || `User #${u.id}`).join(", ")}
              </p>
            </div>
          </div>
        )}

        {/* Tab Navigation */}
        <div className="flex gap-1 mb-6 bg-slate-100 rounded-lg p-1 w-fit">
          <button
            onClick={() => setActiveTab("users")}
            className={`px-4 py-2 rounded-md text-sm font-medium transition-colors flex items-center gap-2 ${
              activeTab === "users"
                ? "bg-white text-slate-900 shadow-sm"
                : "text-slate-500 hover:text-slate-700"
            }`}
          >
            <Users className="h-4 w-4" />
            Benutzerverwaltung
          </button>
          <button
            onClick={() => setActiveTab("messages")}
            className={`px-4 py-2 rounded-md text-sm font-medium transition-colors flex items-center gap-2 ${
              activeTab === "messages"
                ? "bg-white text-slate-900 shadow-sm"
                : "text-slate-500 hover:text-slate-700"
            }`}
          >
            <MessageSquare className="h-4 w-4" />
            Nachrichten
            {stats?.totalMessages ? (
              <Badge variant="secondary" className="text-xs ml-1">
                {stats.totalMessages}
              </Badge>
            ) : null}
          </button>
          <button
            onClick={() => setActiveTab("logs")}
            className={`px-4 py-2 rounded-md text-sm font-medium transition-colors flex items-center gap-2 ${
              activeTab === "logs"
                ? "bg-white text-slate-900 shadow-sm"
                : "text-slate-500 hover:text-slate-700"
            }`}
          >
            <History className="h-4 w-4" />
            Aktivitätsprotokoll
            {stats?.totalActivityLogs ? (
              <Badge variant="secondary" className="text-xs ml-1">
                {stats.totalActivityLogs}
              </Badge>
            ) : null}
          </button>
        </div>

        {/* Tab Content */}
        {activeTab === "users" ? (
          <UserManagement
            users={allUsers}
            currentUserId={user?.id}
            isLoading={usersQuery.isLoading}
            onUpdateRole={(userId, role) => updateRoleMutation.mutate({ userId, role })}
            onUpdateStatus={(userId, status) => updateStatusMutation.mutate({ userId, status })}
            onDeleteUser={(userId) => deleteUserMutation.mutate({ userId })}
          />
        ) : activeTab === "messages" ? (
          <MessageCenter users={allUsers} />
        ) : (
          <ActivityLogViewer />
        )}

        {/* Projekt-Statistiken */}
        <Card className="mt-6">
          <CardHeader>
            <CardTitle className="text-xl font-[Montserrat]">Projekt-Statistiken</CardTitle>
            <CardDescription>
              Übersicht über den aktuellen Projektstatus
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="p-4 rounded-lg bg-emerald-50 border border-emerald-200">
                <div className="flex items-center gap-2 mb-1">
                  <Activity className="h-4 w-4 text-emerald-600" />
                  <span className="text-sm font-medium text-emerald-800">Laufende Projekte</span>
                </div>
                <p className="text-3xl font-bold text-emerald-700">
                  {stats?.activeProjects ?? 0}
                </p>
              </div>
              <div className="p-4 rounded-lg bg-amber-50 border border-amber-200">
                <div className="flex items-center gap-2 mb-1">
                  <FileText className="h-4 w-4 text-amber-600" />
                  <span className="text-sm font-medium text-amber-800">Angebote</span>
                </div>
                <p className="text-3xl font-bold text-amber-700">
                  {stats?.offerProjects ?? 0}
                </p>
              </div>
              <div className="p-4 rounded-lg bg-blue-50 border border-blue-200">
                <div className="flex items-center gap-2 mb-1">
                  <FolderKanban className="h-4 w-4 text-blue-600" />
                  <span className="text-sm font-medium text-blue-800">Projekte gesamt</span>
                </div>
                <p className="text-3xl font-bold text-blue-700">
                  {stats?.totalProjects ?? 0}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}

// ===== Message Center Component =====

function MessageCenter({ users }: { users: any[] }) {
  const [showCompose, setShowCompose] = useState(false);
  const [selectedUserId, setSelectedUserId] = useState<string>("");
  const [subject, setSubject] = useState("");
  const [content, setContent] = useState("");
  const [category, setCategory] = useState<string>("general");
  const [page, setPage] = useState(0);
  const pageSize = 20;

  const utils = trpc.useUtils();

  const messagesQuery = trpc.admin.messages.list.useQuery({
    limit: pageSize,
    offset: page * pageSize,
  });

  const sendMessageMutation = trpc.admin.messages.send.useMutation({
    onSuccess: () => {
      utils.admin.messages.list.invalidate();
      utils.admin.stats.invalidate();
      toast.success("Nachricht erfolgreich gesendet");
      setShowCompose(false);
      resetForm();
    },
    onError: (err) => {
      toast.error("Fehler beim Senden: " + err.message);
    },
  });

  const resetForm = () => {
    setSelectedUserId("");
    setSubject("");
    setContent("");
    setCategory("general");
  };

  const handleSend = () => {
    if (!selectedUserId || !subject.trim() || !content.trim()) {
      toast.error("Bitte füllen Sie alle Pflichtfelder aus.");
      return;
    }
    sendMessageMutation.mutate({
      toUserId: parseInt(selectedUserId),
      subject: subject.trim(),
      content: content.trim(),
      category: category as "info" | "rejection" | "suspension" | "approval" | "general",
    });
  };

  const openComposeForUser = (userId: number, cat: string, subjectText: string) => {
    setSelectedUserId(String(userId));
    setCategory(cat);
    setSubject(subjectText);
    setContent("");
    setShowCompose(true);
  };

  const messages = messagesQuery.data?.messages ?? [];
  const total = messagesQuery.data?.total ?? 0;
  const totalPages = Math.ceil(total / pageSize);

  const categoryLabels: Record<string, { label: string; color: string; icon: React.ReactNode }> = {
    general: { label: "Allgemein", color: "bg-slate-100 text-slate-800", icon: <Mail className="h-3 w-3" /> },
    info: { label: "Information", color: "bg-blue-100 text-blue-800", icon: <Mail className="h-3 w-3" /> },
    rejection: { label: "Ablehnung", color: "bg-red-100 text-red-800", icon: <XCircle className="h-3 w-3" /> },
    suspension: { label: "Sperrung", color: "bg-orange-100 text-orange-800", icon: <Shield className="h-3 w-3" /> },
    approval: { label: "Freischaltung", color: "bg-emerald-100 text-emerald-800", icon: <CheckCircle2 className="h-3 w-3" /> },
  };

  return (
    <>
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-xl font-[Montserrat]">Nachrichtenzentrale</CardTitle>
              <CardDescription className="mt-1">
                Senden Sie Nachrichten an Benutzer bei Ablehnung, Sperrung oder zur allgemeinen Information.
              </CardDescription>
            </div>
            <Button
              onClick={() => { resetForm(); setShowCompose(true); }}
              className="bg-[#005CA9] hover:bg-[#004A87]"
            >
              <Send className="h-4 w-4 mr-2" />
              Neue Nachricht
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {/* Quick Actions */}
          <div className="mb-6 p-4 bg-slate-50 rounded-lg border border-slate-200">
            <h3 className="text-sm font-semibold text-slate-700 mb-3">Schnellaktionen</h3>
            <div className="flex flex-wrap gap-2">
              {users.filter(u => u.status === "pending").map(u => (
                <div key={u.id} className="flex items-center gap-1.5 bg-white rounded-md border border-slate-200 p-2">
                  <div className="h-6 w-6 rounded-full bg-amber-100 flex items-center justify-center text-amber-700 font-semibold text-xs">
                    {u.name?.charAt(0)?.toUpperCase() || "?"}
                  </div>
                  <span className="text-sm font-medium text-slate-700">{u.name || u.email || `User #${u.id}`}</span>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-6 px-2 text-emerald-600 hover:text-emerald-700 hover:bg-emerald-50"
                    onClick={() => openComposeForUser(u.id, "approval", `Ihr Zugang wurde freigeschaltet`)}
                    title="Freischaltungs-Nachricht"
                  >
                    <CheckCircle2 className="h-3.5 w-3.5" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-6 px-2 text-red-600 hover:text-red-700 hover:bg-red-50"
                    onClick={() => openComposeForUser(u.id, "rejection", `Ihr Zugangsantrag wurde abgelehnt`)}
                    title="Ablehnungs-Nachricht"
                  >
                    <XCircle className="h-3.5 w-3.5" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-6 px-2 text-blue-600 hover:text-blue-700 hover:bg-blue-50"
                    onClick={() => openComposeForUser(u.id, "info", ``)}
                    title="Info-Nachricht"
                  >
                    <Mail className="h-3.5 w-3.5" />
                  </Button>
                </div>
              ))}
              {users.filter(u => u.status === "pending").length === 0 && (
                <p className="text-sm text-slate-400">Keine ausstehenden Benutzer vorhanden.</p>
              )}
            </div>
          </div>

          {/* Messages List */}
          {messagesQuery.isLoading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="h-6 w-6 animate-spin text-[#005CA9]" />
            </div>
          ) : messages.length === 0 ? (
            <div className="text-center py-12 text-slate-500">
              <MessageSquare className="h-12 w-12 mx-auto mb-3 text-slate-300" />
              <p>Noch keine Nachrichten gesendet.</p>
              <p className="text-sm mt-1">Verwenden Sie den Button oben, um eine Nachricht zu verfassen.</p>
            </div>
          ) : (
            <>
              <div className="space-y-3">
                {messages.map((msg) => {
                  const catInfo = categoryLabels[msg.category] || categoryLabels.general;
                  return (
                    <div key={msg.id} className="flex items-start gap-3 p-4 rounded-lg border border-slate-200 bg-white hover:bg-slate-50/50 transition-colors">
                      <div className="h-9 w-9 rounded-full bg-[#005CA9]/10 flex items-center justify-center text-[#005CA9] font-semibold text-sm shrink-0">
                        {(msg.toUserName || "?").charAt(0).toUpperCase()}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-medium text-sm text-slate-900">
                            An: {msg.toUserName || `User #${msg.toUserId}`}
                          </span>
                          <Badge className={`${catInfo.color} border-0 text-[10px] gap-1`}>
                            {catInfo.icon}
                            {catInfo.label}
                          </Badge>
                          {msg.isRead === 1 ? (
                            <span title="Gelesen"><MailOpen className="h-3.5 w-3.5 text-emerald-500" /></span>
                          ) : (
                            <span title="Ungelesen"><Mail className="h-3.5 w-3.5 text-slate-400" /></span>
                          )}
                        </div>
                        <p className="text-sm font-semibold text-slate-800 mb-0.5">{msg.subject}</p>
                        <p className="text-sm text-slate-600 line-clamp-2">{msg.content}</p>
                        <div className="flex items-center gap-3 mt-2">
                          <span className="text-xs text-slate-400">
                            Von: {msg.fromUserName || "Admin"}
                          </span>
                          <span className="text-xs text-slate-400">
                            {msg.createdAt
                              ? new Date(msg.createdAt).toLocaleString("de-DE", {
                                  day: "2-digit",
                                  month: "2-digit",
                                  year: "numeric",
                                  hour: "2-digit",
                                  minute: "2-digit",
                                })
                              : "-"}
                          </span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Pagination */}
              {totalPages > 1 && (
                <div className="flex items-center justify-between mt-4 pt-4 border-t border-slate-200">
                  <p className="text-sm text-slate-500">
                    Seite {page + 1} von {totalPages} ({total} Nachrichten)
                  </p>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setPage(Math.max(0, page - 1))}
                      disabled={page === 0}
                    >
                      <ChevronLeft className="h-4 w-4" />
                      Zurück
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setPage(Math.min(totalPages - 1, page + 1))}
                      disabled={page >= totalPages - 1}
                    >
                      Weiter
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              )}
            </>
          )}
        </CardContent>
      </Card>

      {/* Compose Dialog */}
      <Dialog open={showCompose} onOpenChange={setShowCompose}>
        <DialogContent className="sm:max-w-[550px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Send className="h-5 w-5 text-[#005CA9]" />
              Nachricht senden
            </DialogTitle>
            <DialogDescription>
              Verfassen Sie eine Nachricht an einen Benutzer. Der Benutzer sieht die Nachricht beim nächsten Login.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label htmlFor="msg-to">Empfänger *</Label>
              <Select value={selectedUserId} onValueChange={setSelectedUserId}>
                <SelectTrigger id="msg-to">
                  <SelectValue placeholder="Benutzer auswählen..." />
                </SelectTrigger>
                <SelectContent>
                  {users.filter(u => u.id).map(u => (
                    <SelectItem key={u.id} value={String(u.id)}>
                      <div className="flex items-center gap-2">
                        <div className={`h-2 w-2 rounded-full ${
                          u.status === "approved" ? "bg-emerald-500" :
                          u.status === "rejected" ? "bg-red-500" : "bg-amber-500"
                        }`} />
                        {u.name || u.email || `User #${u.id}`}
                        <span className="text-xs text-slate-400">({u.status})</span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="msg-category">Kategorie</Label>
              <Select value={category} onValueChange={setCategory}>
                <SelectTrigger id="msg-category">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="general">
                    <div className="flex items-center gap-2">
                      <Mail className="h-3.5 w-3.5 text-slate-600" />
                      Allgemein
                    </div>
                  </SelectItem>
                  <SelectItem value="info">
                    <div className="flex items-center gap-2">
                      <Mail className="h-3.5 w-3.5 text-blue-600" />
                      Information
                    </div>
                  </SelectItem>
                  <SelectItem value="approval">
                    <div className="flex items-center gap-2">
                      <CheckCircle2 className="h-3.5 w-3.5 text-emerald-600" />
                      Freischaltung
                    </div>
                  </SelectItem>
                  <SelectItem value="rejection">
                    <div className="flex items-center gap-2">
                      <XCircle className="h-3.5 w-3.5 text-red-600" />
                      Ablehnung
                    </div>
                  </SelectItem>
                  <SelectItem value="suspension">
                    <div className="flex items-center gap-2">
                      <Shield className="h-3.5 w-3.5 text-orange-600" />
                      Sperrung
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="msg-subject">Betreff *</Label>
              <Input
                id="msg-subject"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                placeholder="Betreff der Nachricht..."
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="msg-content">Nachricht *</Label>
              <Textarea
                id="msg-content"
                value={content}
                onChange={(e) => setContent(e.target.value)}
                placeholder="Ihre Nachricht an den Benutzer..."
                rows={5}
              />
            </div>

            {/* Template Suggestions */}
            <div className="space-y-2">
              <Label className="text-xs text-slate-500">Vorlagen</Label>
              <div className="flex flex-wrap gap-1.5">
                <Button
                  variant="outline"
                  size="sm"
                  className="text-xs h-7"
                  onClick={() => {
                    setSubject("Ihr Zugang wurde freigeschaltet");
                    setContent("Guten Tag,\n\nIhr Zugang zur Ressourcenplanung wurde freigeschaltet. Sie können sich ab sofort anmelden und die Anwendung nutzen.\n\nBei Fragen stehen wir Ihnen gerne zur Verfügung.\n\nMit freundlichen Grüßen");
                    setCategory("approval");
                  }}
                >
                  Freischaltung
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  className="text-xs h-7"
                  onClick={() => {
                    setSubject("Ihr Zugangsantrag wurde abgelehnt");
                    setContent("Guten Tag,\n\nIhr Zugangsantrag zur Ressourcenplanung konnte leider nicht genehmigt werden.\n\nBitte wenden Sie sich bei Fragen an Ihren Vorgesetzten oder die Abteilungsleitung.\n\nMit freundlichen Grüßen");
                    setCategory("rejection");
                  }}
                >
                  Ablehnung
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  className="text-xs h-7"
                  onClick={() => {
                    setSubject("Ihr Zugang wurde vorübergehend gesperrt");
                    setContent("Guten Tag,\n\nIhr Zugang zur Ressourcenplanung wurde vorübergehend gesperrt.\n\nBitte wenden Sie sich bei Fragen an die Abteilungsleitung.\n\nMit freundlichen Grüßen");
                    setCategory("suspension");
                  }}
                >
                  Sperrung
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  className="text-xs h-7"
                  onClick={() => {
                    setSubject("Information zur Ressourcenplanung");
                    setContent("Guten Tag,\n\n\n\nMit freundlichen Grüßen");
                    setCategory("info");
                  }}
                >
                  Allgemeine Info
                </Button>
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowCompose(false)}>
              Abbrechen
            </Button>
            <Button
              onClick={handleSend}
              disabled={sendMessageMutation.isPending || !selectedUserId || !subject.trim() || !content.trim()}
              className="bg-[#005CA9] hover:bg-[#004A87]"
            >
              {sendMessageMutation.isPending ? (
                <Loader2 className="h-4 w-4 animate-spin mr-2" />
              ) : (
                <Send className="h-4 w-4 mr-2" />
              )}
              Senden
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}

// ===== User Management Component =====

function UserManagement({
  users,
  currentUserId,
  isLoading,
  onUpdateRole,
  onUpdateStatus,
  onDeleteUser,
}: {
  users: any[];
  currentUserId?: number;
  isLoading: boolean;
  onUpdateRole: (userId: number, role: "user" | "admin") => void;
  onUpdateStatus: (userId: number, status: "pending" | "approved" | "rejected") => void;
  onDeleteUser: (userId: number) => void;
}) {
  const [messageDialogUser, setMessageDialogUser] = useState<any>(null);
  const [msgSubject, setMsgSubject] = useState("");
  const [msgContent, setMsgContent] = useState("");
  const [msgCategory, setMsgCategory] = useState<string>("general");
  const utils = trpc.useUtils();

  const sendMessageMutation = trpc.admin.messages.send.useMutation({
    onSuccess: () => {
      utils.admin.messages.list.invalidate();
      utils.admin.stats.invalidate();
      toast.success("Nachricht erfolgreich gesendet");
      setMessageDialogUser(null);
      setMsgSubject("");
      setMsgContent("");
      setMsgCategory("general");
    },
    onError: (err) => {
      toast.error("Fehler beim Senden: " + err.message);
    },
  });

  const statusBadge = (status: string) => {
    switch (status) {
      case "approved":
        return (
          <Badge className="bg-emerald-100 text-emerald-800 border-0 gap-1">
            <CheckCircle2 className="h-3 w-3" />
            Freigeschaltet
          </Badge>
        );
      case "rejected":
        return (
          <Badge className="bg-red-100 text-red-800 border-0 gap-1">
            <XCircle className="h-3 w-3" />
            Abgelehnt
          </Badge>
        );
      case "pending":
      default:
        return (
          <Badge className="bg-amber-100 text-amber-800 border-0 gap-1">
            <Clock className="h-3 w-3" />
            Ausstehend
          </Badge>
        );
    }
  };

  return (
    <>
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-xl font-[Montserrat]">Benutzerverwaltung</CardTitle>
              <CardDescription className="mt-1">
                Verwalten Sie die Benutzer, deren Rollen und Freischaltungsstatus. Nutzen Sie das Nachrichten-Symbol, um direkt mit Benutzern zu kommunizieren.
              </CardDescription>
            </div>
            <Badge variant="outline" className="text-sm">
              {users.length} Benutzer
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="h-6 w-6 animate-spin text-[#005CA9]" />
            </div>
          ) : users.length === 0 ? (
            <div className="text-center py-12 text-slate-500">
              <Users className="h-12 w-12 mx-auto mb-3 text-slate-300" />
              <p>Noch keine Benutzer registriert.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="bg-slate-50">
                    <TableHead className="font-semibold">ID</TableHead>
                    <TableHead className="font-semibold">Name</TableHead>
                    <TableHead className="font-semibold">E-Mail</TableHead>
                    <TableHead className="font-semibold">Status</TableHead>
                    <TableHead className="font-semibold">Rolle</TableHead>
                    <TableHead className="font-semibold">Letzter Login</TableHead>
                    <TableHead className="font-semibold">Registriert</TableHead>
                    <TableHead className="font-semibold text-right">Aktionen</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {users.map((u) => (
                    <TableRow key={u.id} className={`hover:bg-slate-50/50 ${u.status === "pending" ? "bg-amber-50/30" : ""}`}>
                      <TableCell className="font-mono text-sm text-slate-500">
                        #{u.id}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <div className="h-8 w-8 rounded-full bg-[#005CA9]/10 flex items-center justify-center text-[#005CA9] font-semibold text-sm">
                            {u.name?.charAt(0)?.toUpperCase() || "?"}
                          </div>
                          <span className="font-medium">{u.name || "-"}</span>
                        </div>
                      </TableCell>
                      <TableCell className="text-slate-600">
                        {u.email || "-"}
                      </TableCell>
                      <TableCell>
                        {statusBadge(u.status)}
                      </TableCell>
                      <TableCell>
                        <Select
                          value={u.role}
                          onValueChange={(newRole: "user" | "admin") => {
                            onUpdateRole(u.id, newRole);
                          }}
                        >
                          <SelectTrigger className="w-[120px] h-8">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="user">
                              <div className="flex items-center gap-2">
                                <div className="h-2 w-2 rounded-full bg-slate-400" />
                                Benutzer
                              </div>
                            </SelectItem>
                            <SelectItem value="admin">
                              <div className="flex items-center gap-2">
                                <div className="h-2 w-2 rounded-full bg-amber-500" />
                                Admin
                              </div>
                            </SelectItem>
                          </SelectContent>
                        </Select>
                      </TableCell>
                      <TableCell className="text-slate-600 text-sm">
                        {u.lastSignedIn
                          ? new Date(u.lastSignedIn).toLocaleString("de-DE", {
                              day: "2-digit",
                              month: "2-digit",
                              year: "numeric",
                              hour: "2-digit",
                              minute: "2-digit",
                            })
                          : "-"}
                      </TableCell>
                      <TableCell className="text-slate-600 text-sm">
                        {u.createdAt
                          ? new Date(u.createdAt).toLocaleString("de-DE", {
                              day: "2-digit",
                              month: "2-digit",
                              year: "numeric",
                            })
                          : "-"}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-1">
                          {u.id !== currentUserId && (
                            <>
                              {/* Message Button */}
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => {
                                  setMessageDialogUser(u);
                                  setMsgSubject("");
                                  setMsgContent("");
                                  setMsgCategory("general");
                                }}
                                className="text-[#005CA9] hover:text-[#004A87] hover:bg-blue-50"
                                title="Nachricht senden"
                              >
                                <MessageSquare className="h-4 w-4" />
                              </Button>
                              {u.status !== "approved" && (
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => onUpdateStatus(u.id, "approved")}
                                  className="text-emerald-600 hover:text-emerald-700 hover:bg-emerald-50"
                                  title="Freischalten"
                                >
                                  <UserCheck className="h-4 w-4" />
                                </Button>
                              )}
                              {u.status !== "rejected" && (
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => onUpdateStatus(u.id, "rejected")}
                                  className="text-amber-600 hover:text-amber-700 hover:bg-amber-50"
                                  title="Ablehnen"
                                >
                                  <UserX className="h-4 w-4" />
                                </Button>
                              )}
                              <AlertDialog>
                                <AlertDialogTrigger asChild>
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    className="text-red-500 hover:text-red-700 hover:bg-red-50"
                                  >
                                    <Trash2 className="h-4 w-4" />
                                  </Button>
                                </AlertDialogTrigger>
                                <AlertDialogContent>
                                  <AlertDialogHeader>
                                    <AlertDialogTitle>Benutzer löschen?</AlertDialogTitle>
                                    <AlertDialogDescription>
                                      Möchten Sie den Benutzer <strong>{u.name || u.email}</strong> wirklich
                                      löschen? Diese Aktion kann nicht rückgängig gemacht werden.
                                    </AlertDialogDescription>
                                  </AlertDialogHeader>
                                  <AlertDialogFooter>
                                    <AlertDialogCancel>Abbrechen</AlertDialogCancel>
                                    <AlertDialogAction
                                      onClick={() => onDeleteUser(u.id)}
                                      className="bg-red-600 hover:bg-red-700"
                                    >
                                      Löschen
                                    </AlertDialogAction>
                                  </AlertDialogFooter>
                                </AlertDialogContent>
                              </AlertDialog>
                            </>
                          )}
                          {u.id === currentUserId && (
                            <Badge variant="outline" className="text-xs">
                              Sie
                            </Badge>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Inline Message Dialog from User Table */}
      <Dialog open={messageDialogUser !== null} onOpenChange={(open) => !open && setMessageDialogUser(null)}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Send className="h-5 w-5 text-[#005CA9]" />
              Nachricht an {messageDialogUser?.name || messageDialogUser?.email || "Benutzer"}
            </DialogTitle>
            <DialogDescription>
              Senden Sie eine direkte Nachricht an diesen Benutzer.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label>Kategorie</Label>
              <Select value={msgCategory} onValueChange={setMsgCategory}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="general">Allgemein</SelectItem>
                  <SelectItem value="info">Information</SelectItem>
                  <SelectItem value="approval">Freischaltung</SelectItem>
                  <SelectItem value="rejection">Ablehnung</SelectItem>
                  <SelectItem value="suspension">Sperrung</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Betreff *</Label>
              <Input
                value={msgSubject}
                onChange={(e) => setMsgSubject(e.target.value)}
                placeholder="Betreff..."
              />
            </div>

            <div className="space-y-2">
              <Label>Nachricht *</Label>
              <Textarea
                value={msgContent}
                onChange={(e) => setMsgContent(e.target.value)}
                placeholder="Ihre Nachricht..."
                rows={4}
              />
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setMessageDialogUser(null)}>
              Abbrechen
            </Button>
            <Button
              onClick={() => {
                if (!msgSubject.trim() || !msgContent.trim()) {
                  toast.error("Bitte füllen Sie Betreff und Nachricht aus.");
                  return;
                }
                sendMessageMutation.mutate({
                  toUserId: messageDialogUser.id,
                  subject: msgSubject.trim(),
                  content: msgContent.trim(),
                  category: msgCategory as any,
                });
              }}
              disabled={sendMessageMutation.isPending}
              className="bg-[#005CA9] hover:bg-[#004A87]"
            >
              {sendMessageMutation.isPending ? (
                <Loader2 className="h-4 w-4 animate-spin mr-2" />
              ) : (
                <Send className="h-4 w-4 mr-2" />
              )}
              Senden
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}

// ===== Activity Log Viewer Component =====

function ActivityLogViewer() {
  const [page, setPage] = useState(0);
  const pageSize = 25;

  const logsQuery = trpc.admin.activityLogs.list.useQuery({
    limit: pageSize,
    offset: page * pageSize,
  });

  const logs = logsQuery.data?.logs ?? [];
  const total = logsQuery.data?.total ?? 0;
  const totalPages = Math.ceil(total / pageSize);

  const actionLabels: Record<string, { label: string; color: string }> = {
    create: { label: "Erstellt", color: "bg-emerald-100 text-emerald-800" },
    update: { label: "Aktualisiert", color: "bg-blue-100 text-blue-800" },
    delete: { label: "Gelöscht", color: "bg-red-100 text-red-800" },
    login: { label: "Anmeldung", color: "bg-slate-100 text-slate-800" },
    logout: { label: "Abmeldung", color: "bg-slate-100 text-slate-800" },
    approve_user: { label: "Freigeschaltet", color: "bg-emerald-100 text-emerald-800" },
    reject_user: { label: "Abgelehnt", color: "bg-red-100 text-red-800" },
    change_role: { label: "Rolle geändert", color: "bg-purple-100 text-purple-800" },
    csv_import: { label: "CSV Import", color: "bg-indigo-100 text-indigo-800" },
    csv_export: { label: "CSV Export", color: "bg-indigo-100 text-indigo-800" },
    send_message: { label: "Nachricht", color: "bg-teal-100 text-teal-800" },
  };

  const entityLabels: Record<string, string> = {
    project: "Projekt",
    user: "Benutzer",
    system: "System",
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-xl font-[Montserrat]">Aktivitätsprotokoll</CardTitle>
            <CardDescription className="mt-1">
              Alle Benutzeraktionen werden hier protokolliert und sind nachvollziehbar.
            </CardDescription>
          </div>
          <Badge variant="outline" className="text-sm">
            {total} Einträge
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        {logsQuery.isLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="h-6 w-6 animate-spin text-[#005CA9]" />
          </div>
        ) : logs.length === 0 ? (
          <div className="text-center py-12 text-slate-500">
            <History className="h-12 w-12 mx-auto mb-3 text-slate-300" />
            <p>Noch keine Aktivitäten protokolliert.</p>
          </div>
        ) : (
          <>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="bg-slate-50">
                    <TableHead className="font-semibold w-[160px]">Zeitpunkt</TableHead>
                    <TableHead className="font-semibold">Benutzer</TableHead>
                    <TableHead className="font-semibold">Aktion</TableHead>
                    <TableHead className="font-semibold">Bereich</TableHead>
                    <TableHead className="font-semibold">Objekt</TableHead>
                    <TableHead className="font-semibold">Details</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {logs.map((log) => {
                    const actionInfo = actionLabels[log.action] || { label: log.action, color: "bg-slate-100 text-slate-800" };
                    return (
                      <TableRow key={log.id} className="hover:bg-slate-50/50">
                        <TableCell className="text-sm text-slate-600 whitespace-nowrap">
                          {log.createdAt
                            ? new Date(log.createdAt).toLocaleString("de-DE", {
                                day: "2-digit",
                                month: "2-digit",
                                year: "numeric",
                                hour: "2-digit",
                                minute: "2-digit",
                                second: "2-digit",
                              })
                            : "-"}
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <div className="h-6 w-6 rounded-full bg-[#005CA9]/10 flex items-center justify-center text-[#005CA9] font-semibold text-xs">
                              {(log.userName || "?").charAt(0).toUpperCase()}
                            </div>
                            <span className="text-sm font-medium">{log.userName || "-"}</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge className={`${actionInfo.color} border-0 text-xs`}>
                            {actionInfo.label}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-sm text-slate-600">
                          {entityLabels[log.entity] || log.entity}
                        </TableCell>
                        <TableCell className="text-sm text-slate-700 font-medium max-w-[200px] truncate">
                          {log.entityName || "-"}
                        </TableCell>
                        <TableCell className="text-sm text-slate-500 max-w-[300px] truncate">
                          {log.details || "-"}
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>

            {/* Pagination */}
            {totalPages > 1 && (
              <div className="flex items-center justify-between mt-4 pt-4 border-t border-slate-200">
                <p className="text-sm text-slate-500">
                  Seite {page + 1} von {totalPages} ({total} Einträge)
                </p>
                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setPage(Math.max(0, page - 1))}
                    disabled={page === 0}
                  >
                    <ChevronLeft className="h-4 w-4" />
                    Zurück
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setPage(Math.min(totalPages - 1, page + 1))}
                    disabled={page >= totalPages - 1}
                  >
                    Weiter
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            )}
          </>
        )}
      </CardContent>
    </Card>
  );
}

// ===== Stat Card Component =====

function StatCard({
  icon,
  label,
  value,
  loading,
  highlight,
}: {
  icon: React.ReactNode;
  label: string;
  value: number;
  loading: boolean;
  highlight?: boolean;
}) {
  return (
    <Card className={highlight ? "ring-2 ring-amber-300 bg-amber-50/50" : ""}>
      <CardContent className="pt-6">
        <div className="flex items-center gap-3">
          <div className={`p-2 rounded-lg ${highlight ? "bg-amber-100" : "bg-slate-100"}`}>{icon}</div>
          <div>
            <p className="text-sm text-slate-500">{label}</p>
            {loading ? (
              <Loader2 className="h-5 w-5 animate-spin text-slate-400 mt-1" />
            ) : (
              <p className={`text-2xl font-bold ${highlight ? "text-amber-700" : "text-slate-900"}`}>{value}</p>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
