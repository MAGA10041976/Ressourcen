import { useMemo, useState, useRef, useCallback, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { ArrowLeft, Calendar, Filter, ZoomIn, ZoomOut, Info, ChevronLeft, ChevronRight, Link2, Trash2, GripVertical } from "lucide-react";
import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { toast } from "sonner";

type Project = {
  id: number;
  kunde: string;
  projekt: string;
  status: string;
  geplanterStart: string | null;
  startDate: string | null;
  endDate: string | null;
  dependencies: string | null;
  mentorSupport: string | null;
  ktmLead: string | null;
  mitarbeiter: string | null;
  qaa: string | null;
  wahrscheinlichkeit: number;
  stunden: number | null;
  bestellung: number;
  bemerkung: string | null;
};

const STATUS_COLORS: Record<string, { bg: string; text: string; bar: string }> = {
  "läuft": { bg: "bg-emerald-100", text: "text-emerald-800", bar: "#059669" },
  "Angebot": { bg: "bg-amber-100", text: "text-amber-800", bar: "#d97706" },
  "BD": { bg: "bg-blue-100", text: "text-blue-800", bar: "#2563eb" },
  "BD/DD": { bg: "bg-indigo-100", text: "text-indigo-800", bar: "#4f46e5" },
  "CD": { bg: "bg-purple-100", text: "text-purple-800", bar: "#7c3aed" },
  "DD": { bg: "bg-cyan-100", text: "text-cyan-800", bar: "#0891b2" },
};

function parseKWDate(geplanterStart: string | null): Date | null {
  if (!geplanterStart) return null;
  const isoMatch = geplanterStart.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (isoMatch) {
    return new Date(parseInt(isoMatch[1]), parseInt(isoMatch[2]) - 1, parseInt(isoMatch[3]));
  }
  const kwMatch = geplanterStart.match(/KW\s*(\d+)/i);
  if (kwMatch) {
    const kw = parseInt(kwMatch[1]);
    const yearMatch = geplanterStart.match(/(\d{4})/);
    const year = yearMatch ? parseInt(yearMatch[1]) : 2026;
    const jan4 = new Date(year, 0, 4);
    const dayOfWeek = jan4.getDay() || 7;
    const firstMonday = new Date(jan4);
    firstMonday.setDate(jan4.getDate() - dayOfWeek + 1);
    const result = new Date(firstMonday);
    result.setDate(result.getDate() + (kw - 1) * 7);
    return result;
  }
  const qMatch = geplanterStart.match(/Q(\d)\s*(\d{4})?/i);
  if (qMatch) {
    const quarter = parseInt(qMatch[1]);
    const year = qMatch[2] ? parseInt(qMatch[2]) : 2026;
    return new Date(year, (quarter - 1) * 3, 1);
  }
  return null;
}

function getProjectDates(project: Project): { start: Date; end: Date } | null {
  let start: Date | null = null;
  let end: Date | null = null;

  if (project.startDate) {
    const parsed = new Date(project.startDate);
    if (!isNaN(parsed.getTime())) start = parsed;
  }
  if (!start) {
    start = parseKWDate(project.geplanterStart);
  }
  if (!start) return null;

  if (project.endDate) {
    const parsed = new Date(project.endDate);
    if (!isNaN(parsed.getTime())) end = parsed;
  }
  if (!end) {
    const hours = project.stunden || 500;
    const months = Math.max(1, Math.ceil(hours / 160));
    end = new Date(start);
    end.setMonth(end.getMonth() + months);
  }

  return { start, end };
}

function formatDate(date: Date): string {
  return date.toLocaleDateString("de-DE", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
  });
}

function getMonthsBetween(start: Date, end: Date): Date[] {
  const months: Date[] = [];
  const current = new Date(start.getFullYear(), start.getMonth(), 1);
  while (current <= end) {
    months.push(new Date(current));
    current.setMonth(current.getMonth() + 1);
  }
  return months;
}

// Dependency arrow colors
const DEP_COLORS = ["#ef4444", "#8b5cf6", "#f59e0b", "#10b981", "#ec4899", "#06b6d4"];

export default function Gantt() {
  const { data: projects, isLoading } = trpc.projects.list.useQuery();
  const updateMutation = trpc.projects.update.useMutation({
    onSuccess: () => {
      utils.projects.list.invalidate();
    },
  });
  const utils = trpc.useUtils();
  const [, setLocation] = useLocation();
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [zoomLevel, setZoomLevel] = useState(1);
  const [viewOffset, setViewOffset] = useState(0);
  const [dragMode, setDragMode] = useState(false);
  const [dragSource, setDragSource] = useState<number | null>(null);
  const [dragTarget, setDragTarget] = useState<number | null>(null);
  const [deleteConfirm, setDeleteConfirm] = useState<{ fromId: number; toId: number } | null>(null);
  const chartRef = useRef<HTMLDivElement>(null);
  const barRefs = useRef<Map<number, HTMLDivElement>>(new Map());
  const [barPositions, setBarPositions] = useState<Map<number, DOMRect>>(new Map());

  // Parse projects with dates
  const projectsWithDates = useMemo(() => {
    if (!projects) return [];
    return projects
      .map((p) => {
        const dates = getProjectDates(p as Project);
        return dates ? { ...p, parsedStart: dates.start, parsedEnd: dates.end } : null;
      })
      .filter(Boolean) as (Project & { parsedStart: Date; parsedEnd: Date })[];
  }, [projects]);

  const filteredProjects = useMemo(() => {
    if (statusFilter === "all") return projectsWithDates;
    return projectsWithDates.filter((p) => p.status === statusFilter);
  }, [projectsWithDates, statusFilter]);

  // Calculate timeline range
  const timelineRange = useMemo(() => {
    if (filteredProjects.length === 0) {
      const now = new Date();
      return {
        start: new Date(now.getFullYear(), now.getMonth() - 1, 1),
        end: new Date(now.getFullYear(), now.getMonth() + 12, 1),
      };
    }
    const starts = filteredProjects.map((p) => p.parsedStart.getTime());
    const ends = filteredProjects.map((p) => p.parsedEnd.getTime());
    const minDate = new Date(Math.min(...starts));
    const maxDate = new Date(Math.max(...ends));
    minDate.setMonth(minDate.getMonth() - 1);
    maxDate.setMonth(maxDate.getMonth() + 1);
    return {
      start: new Date(minDate.getFullYear(), minDate.getMonth(), 1),
      end: new Date(maxDate.getFullYear(), maxDate.getMonth() + 1, 0),
    };
  }, [filteredProjects]);

  const months = useMemo(() => {
    return getMonthsBetween(timelineRange.start, timelineRange.end);
  }, [timelineRange]);

  const visibleMonths = useMemo(() => {
    const count = Math.round(12 / zoomLevel);
    const start = Math.max(0, viewOffset);
    const end = Math.min(months.length, start + count);
    return months.slice(start, end);
  }, [months, zoomLevel, viewOffset]);

  const visibleStart = visibleMonths.length > 0 ? visibleMonths[0] : timelineRange.start;
  const visibleEnd = visibleMonths.length > 0
    ? new Date(visibleMonths[visibleMonths.length - 1].getFullYear(), visibleMonths[visibleMonths.length - 1].getMonth() + 1, 0)
    : timelineRange.end;
  const totalVisibleDays = (visibleEnd.getTime() - visibleStart.getTime()) / (1000 * 60 * 60 * 24);

  const getBarPosition = useCallback((start: Date, end: Date) => {
    const startOffset = Math.max(0, (start.getTime() - visibleStart.getTime()) / (1000 * 60 * 60 * 24));
    const endOffset = Math.min(totalVisibleDays, (end.getTime() - visibleStart.getTime()) / (1000 * 60 * 60 * 24));
    const left = (startOffset / totalVisibleDays) * 100;
    const width = ((endOffset - startOffset) / totalVisibleDays) * 100;
    return { left: Math.max(0, left), width: Math.max(0.5, Math.min(100 - left, width)) };
  }, [visibleStart, totalVisibleDays]);

  const today = new Date();
  const todayPosition = (() => {
    const offset = (today.getTime() - visibleStart.getTime()) / (1000 * 60 * 60 * 24);
    return (offset / totalVisibleDays) * 100;
  })();

  const projectsWithoutDates = useMemo(() => {
    if (!projects) return [];
    return projects.filter((p) => {
      const dates = getProjectDates(p as Project);
      return !dates;
    });
  }, [projects]);

  const maxOffset = Math.max(0, months.length - Math.round(12 / zoomLevel));

  // Parse dependencies from all projects
  const dependencies = useMemo(() => {
    if (!projects) return [];
    const deps: { fromId: number; toId: number }[] = [];
    projects.forEach((p) => {
      if (p.dependencies) {
        const depIds = p.dependencies.split(",").map(s => parseInt(s.trim())).filter(n => !isNaN(n));
        depIds.forEach(depId => {
          deps.push({ fromId: depId, toId: p.id });
        });
      }
    });
    return deps;
  }, [projects]);

  // Update bar positions after render
  useEffect(() => {
    const updatePositions = () => {
      const newPositions = new Map<number, DOMRect>();
      barRefs.current.forEach((el, id) => {
        if (el && chartRef.current) {
          const chartRect = chartRef.current.getBoundingClientRect();
          const barRect = el.getBoundingClientRect();
          newPositions.set(id, new DOMRect(
            barRect.x - chartRect.x,
            barRect.y - chartRect.y,
            barRect.width,
            barRect.height
          ));
        }
      });
      setBarPositions(newPositions);
    };
    // Small delay to ensure DOM is rendered
    const timer = setTimeout(updatePositions, 100);
    return () => clearTimeout(timer);
  }, [filteredProjects, visibleMonths, zoomLevel, viewOffset]);

  // Handle drag-and-drop dependency creation
  const handleBarMouseDown = useCallback((projectId: number, e: React.MouseEvent) => {
    if (!dragMode) return;
    e.preventDefault();
    e.stopPropagation();
    setDragSource(projectId);
    setDragTarget(null);
  }, [dragMode]);

  const handleBarMouseEnter = useCallback((projectId: number) => {
    if (!dragMode || dragSource === null || dragSource === projectId) return;
    setDragTarget(projectId);
  }, [dragMode, dragSource]);

  const handleBarMouseLeave = useCallback(() => {
    if (!dragMode || dragSource === null) return;
    setDragTarget(null);
  }, [dragMode, dragSource]);

  const handleMouseUp = useCallback(() => {
    if (!dragMode || dragSource === null) return;
    if (dragTarget !== null && dragSource !== dragTarget) {
      // Check if dependency already exists
      const existingDeps = dependencies.filter(d => d.fromId === dragSource && d.toId === dragTarget);
      if (existingDeps.length > 0) {
        toast.error("Diese Abhängigkeit existiert bereits.");
      } else {
        // Check for circular dependency
        const wouldCreateCycle = (from: number, to: number): boolean => {
          const visited = new Set<number>();
          const queue = [from];
          while (queue.length > 0) {
            const current = queue.shift()!;
            if (current === to) return true;
            if (visited.has(current)) continue;
            visited.add(current);
            dependencies
              .filter(d => d.toId === current)
              .forEach(d => queue.push(d.fromId));
          }
          return false;
        };

        if (wouldCreateCycle(dragTarget, dragSource)) {
          toast.error("Zirkuläre Abhängigkeit erkannt! Diese Verbindung würde einen Kreis erzeugen.");
        } else {
          // Add dependency: update the target project's dependencies field
          const targetProject = projects?.find(p => p.id === dragTarget);
          if (targetProject) {
            const currentDeps = targetProject.dependencies
              ? targetProject.dependencies.split(",").map(s => s.trim()).filter(s => s)
              : [];
            currentDeps.push(String(dragSource));
            updateMutation.mutate({
              id: dragTarget,
              data: { dependencies: currentDeps.join(",") },
            });
            toast.success(`Abhängigkeit erstellt: Projekt wird nach dem Vorgänger geplant.`);
          }
        }
      }
    }
    setDragSource(null);
    setDragTarget(null);
  }, [dragMode, dragSource, dragTarget, dependencies, projects, updateMutation]);

  const handleDeleteDependency = useCallback((fromId: number, toId: number) => {
    const targetProject = projects?.find(p => p.id === toId);
    if (targetProject) {
      const currentDeps = targetProject.dependencies
        ? targetProject.dependencies.split(",").map(s => s.trim()).filter(s => s)
        : [];
      const newDeps = currentDeps.filter(d => parseInt(d) !== fromId);
      updateMutation.mutate({
        id: toId,
        data: { dependencies: newDeps.join(",") },
      });
      toast.success("Abhängigkeit entfernt.");
    }
    setDeleteConfirm(null);
  }, [projects, updateMutation]);

  // SVG dependency lines
  const renderDependencyLines = useCallback(() => {
    if (barPositions.size === 0) return null;

    const visibleProjectIds = new Set(filteredProjects.map(p => p.id));
    const visibleDeps = dependencies.filter(
      d => visibleProjectIds.has(d.fromId) && visibleProjectIds.has(d.toId)
    );

    return visibleDeps.map((dep, idx) => {
      const fromRect = barPositions.get(dep.fromId);
      const toRect = barPositions.get(dep.toId);
      if (!fromRect || !toRect) return null;

      const color = DEP_COLORS[idx % DEP_COLORS.length];
      const fromX = fromRect.x + fromRect.width;
      const fromY = fromRect.y + fromRect.height / 2;
      const toX = toRect.x;
      const toY = toRect.y + toRect.height / 2;

      // Create a smooth bezier curve
      const midX = (fromX + toX) / 2;
      const controlOffset = Math.max(30, Math.abs(toX - fromX) * 0.3);

      // Arrow path
      const path = toX > fromX
        ? `M ${fromX} ${fromY} C ${fromX + controlOffset} ${fromY}, ${toX - controlOffset} ${toY}, ${toX} ${toY}`
        : `M ${fromX} ${fromY} L ${fromX + 15} ${fromY} L ${fromX + 15} ${(fromY + toY) / 2} L ${toX - 15} ${(fromY + toY) / 2} L ${toX - 15} ${toY} L ${toX} ${toY}`;

      const arrowId = `arrow-${dep.fromId}-${dep.toId}`;

      return (
        <g key={`${dep.fromId}-${dep.toId}`} className="cursor-pointer group" onClick={() => setDeleteConfirm(dep)}>
          <defs>
            <marker
              id={arrowId}
              markerWidth="8"
              markerHeight="6"
              refX="8"
              refY="3"
              orient="auto"
            >
              <polygon points="0 0, 8 3, 0 6" fill={color} />
            </marker>
          </defs>
          {/* Invisible wider path for easier clicking */}
          <path
            d={path}
            fill="none"
            stroke="transparent"
            strokeWidth="12"
          />
          <path
            d={path}
            fill="none"
            stroke={color}
            strokeWidth="2"
            strokeDasharray={dragMode ? "6 3" : "none"}
            markerEnd={`url(#${arrowId})`}
            className="transition-all group-hover:stroke-[3px]"
            opacity={0.7}
          />
          {/* Small delete icon on hover */}
          <foreignObject
            x={midX - 10}
            y={Math.min(fromY, toY) + (Math.abs(toY - fromY) / 2) - 10}
            width="20"
            height="20"
            className="opacity-0 group-hover:opacity-100 transition-opacity"
          >
            <div className="w-5 h-5 bg-red-500 rounded-full flex items-center justify-center text-white cursor-pointer shadow-sm">
              <Trash2 size={10} />
            </div>
          </foreignObject>
        </g>
      );
    });
  }, [barPositions, dependencies, filteredProjects, dragMode]);

  // Drag preview line
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  useEffect(() => {
    if (!dragMode || dragSource === null) return;
    const handleMouseMove = (e: MouseEvent) => {
      if (chartRef.current) {
        const rect = chartRef.current.getBoundingClientRect();
        setMousePos({ x: e.clientX - rect.x, y: e.clientY - rect.y });
      }
    };
    window.addEventListener("mousemove", handleMouseMove);
    window.addEventListener("mouseup", handleMouseUp);
    return () => {
      window.removeEventListener("mousemove", handleMouseMove);
      window.removeEventListener("mouseup", handleMouseUp);
    };
  }, [dragMode, dragSource, handleMouseUp]);

  const renderDragLine = useCallback(() => {
    if (!dragMode || dragSource === null) return null;
    const fromRect = barPositions.get(dragSource);
    if (!fromRect) return null;

    const fromX = fromRect.x + fromRect.width;
    const fromY = fromRect.y + fromRect.height / 2;
    const toX = mousePos.x;
    const toY = mousePos.y;

    return (
      <line
        x1={fromX}
        y1={fromY}
        x2={toX}
        y2={toY}
        stroke={dragTarget !== null ? "#22c55e" : "#94a3b8"}
        strokeWidth="2"
        strokeDasharray="6 3"
        opacity={0.8}
      />
    );
  }, [dragMode, dragSource, dragTarget, barPositions, mousePos]);

  // Dependency list for info display
  const depListForProject = useCallback((projectId: number) => {
    const incoming = dependencies.filter(d => d.toId === projectId);
    const outgoing = dependencies.filter(d => d.fromId === projectId);
    return { incoming, outgoing };
  }, [dependencies]);

  return (
    <div className="min-h-screen bg-white">
      <Navbar />

      {/* Hero */}
      <section className="pt-24 pb-12 bg-gradient-to-br from-[#07284A] to-[#005CA9]">
        <div className="container">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <Button
              variant="ghost"
              onClick={() => setLocation("/")}
              className="text-white/70 hover:text-white hover:bg-white/10 mb-4"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Zur Startseite
            </Button>
            <div className="flex items-center gap-3 mb-3">
              <Calendar className="h-8 w-8 text-white/80" />
              <h1 className="text-3xl lg:text-4xl font-bold text-white" style={{ fontFamily: "'Montserrat', sans-serif" }}>
                Projekt-Timeline
              </h1>
            </div>
            <p className="text-white/70 text-lg max-w-2xl">
              Visuelle Übersicht aller Projekte mit Zeitplanung und Abhängigkeiten.
              {dragMode && (
                <span className="block mt-2 text-amber-300 font-medium">
                  Abhängigkeits-Modus aktiv: Klicken Sie auf ein Projekt und ziehen Sie zum Zielprojekt.
                </span>
              )}
            </p>
          </motion.div>
        </div>
      </section>

      <main className="container py-8">
        {/* Controls */}
        <Card className="mb-6">
          <CardContent className="pt-6">
            <div className="flex flex-wrap items-center gap-4">
              <div className="flex items-center gap-2">
                <Filter className="h-4 w-4 text-slate-500" />
                <span className="text-sm font-medium text-slate-700">Status:</span>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-[160px] h-9">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Alle Status</SelectItem>
                    <SelectItem value="läuft">Läuft</SelectItem>
                    <SelectItem value="Angebot">Angebot</SelectItem>
                    <SelectItem value="BD">BD</SelectItem>
                    <SelectItem value="BD/DD">BD/DD</SelectItem>
                    <SelectItem value="CD">CD</SelectItem>
                    <SelectItem value="DD">DD</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-center gap-1.5">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setViewOffset(Math.max(0, viewOffset - 3))}
                  disabled={viewOffset <= 0}
                >
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                <Button variant="outline" size="sm" onClick={() => setZoomLevel(Math.min(3, zoomLevel + 0.5))} title="Hineinzoomen">
                  <ZoomIn className="h-4 w-4" />
                </Button>
                <span className="text-xs text-slate-500 min-w-[40px] text-center">{Math.round(zoomLevel * 100)}%</span>
                <Button variant="outline" size="sm" onClick={() => setZoomLevel(Math.max(0.5, zoomLevel - 0.5))} title="Herauszoomen">
                  <ZoomOut className="h-4 w-4" />
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setViewOffset(Math.min(maxOffset, viewOffset + 3))}
                  disabled={viewOffset >= maxOffset}
                >
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>

              <div className="ml-auto flex items-center gap-2">
                <Button
                  variant={dragMode ? "default" : "outline"}
                  size="sm"
                  onClick={() => {
                    setDragMode(!dragMode);
                    setDragSource(null);
                    setDragTarget(null);
                  }}
                  className={dragMode ? "bg-amber-500 hover:bg-amber-600 text-white" : ""}
                >
                  <Link2 className="h-4 w-4 mr-1.5" />
                  {dragMode ? "Modus beenden" : "Abhängigkeiten"}
                </Button>
              </div>
            </div>

            {dragMode && (
              <div className="mt-3 p-3 bg-amber-50 border border-amber-200 rounded-lg">
                <div className="flex items-start gap-2">
                  <GripVertical className="h-4 w-4 text-amber-600 mt-0.5 shrink-0" />
                  <div className="text-sm text-amber-800">
                    <p className="font-medium mb-1">Abhängigkeits-Modus</p>
                    <p className="text-xs text-amber-600">
                      Klicken Sie auf ein Quell-Projekt (Vorgänger) und ziehen Sie zum Ziel-Projekt (Nachfolger), um eine Abhängigkeit zu erstellen.
                      Klicken Sie auf eine bestehende Verbindungslinie, um sie zu löschen.
                    </p>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Legend */}
        <div className="flex flex-wrap gap-3 mb-4">
          {Object.entries(STATUS_COLORS).map(([status, colors]) => (
            <div key={status} className="flex items-center gap-1.5">
              <div className="w-3 h-3 rounded-sm" style={{ backgroundColor: colors.bar }} />
              <span className="text-xs text-slate-600">{status}</span>
            </div>
          ))}
          <div className="flex items-center gap-1.5 ml-2">
            <div className="w-3 h-0 border-t-2 border-dashed border-red-500" />
            <span className="text-xs text-slate-600">Heute</span>
          </div>
          {dependencies.length > 0 && (
            <div className="flex items-center gap-1.5 ml-2">
              <svg width="20" height="12" className="inline-block">
                <line x1="0" y1="6" x2="14" y2="6" stroke="#8b5cf6" strokeWidth="2" />
                <polygon points="14,2 20,6 14,10" fill="#8b5cf6" />
              </svg>
              <span className="text-xs text-slate-600">Abhängigkeit ({dependencies.length})</span>
            </div>
          )}
        </div>

        {/* Gantt Chart */}
        <Card>
          <CardContent className="p-0">
            {isLoading ? (
              <div className="flex items-center justify-center py-20">
                <div className="text-center">
                  <div className="w-8 h-8 border-2 border-[#005CA9] border-t-transparent rounded-full animate-spin mx-auto mb-3" />
                  <p className="text-slate-500">Lade Projektdaten...</p>
                </div>
              </div>
            ) : filteredProjects.length === 0 ? (
              <div className="flex items-center justify-center py-20">
                <div className="text-center">
                  <Calendar className="h-12 w-12 text-slate-300 mx-auto mb-3" />
                  <p className="text-slate-500 font-medium">Keine Projekte mit Zeitdaten gefunden</p>
                  <p className="text-sm text-slate-400 mt-1">
                    Tragen Sie Start- und Enddaten in der Projektübersicht ein.
                  </p>
                </div>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <div className="min-w-[800px]" ref={chartRef} style={{ position: "relative" }}>
                  {/* Timeline Header */}
                  <div className="flex border-b border-slate-200 bg-slate-50 sticky top-0 z-20">
                    <div className="w-[280px] min-w-[280px] px-4 py-3 border-r border-slate-200">
                      <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                        Projekt
                      </span>
                    </div>
                    <div className="flex-1 flex relative">
                      {visibleMonths.map((month, i) => {
                        const isCurrentMonth =
                          month.getMonth() === today.getMonth() &&
                          month.getFullYear() === today.getFullYear();
                        return (
                          <div
                            key={i}
                            className={`flex-1 px-2 py-3 text-center border-r border-slate-100 last:border-r-0 ${
                              isCurrentMonth ? "bg-blue-50" : ""
                            }`}
                          >
                            <span className={`text-xs font-medium ${isCurrentMonth ? "text-[#005CA9]" : "text-slate-500"}`}>
                              {month.toLocaleDateString("de-DE", { month: "short" })}
                            </span>
                            <br />
                            <span className="text-[10px] text-slate-400">
                              {month.getFullYear()}
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* Project Rows */}
                  {filteredProjects.map((project, idx) => {
                    const pos = getBarPosition(project.parsedStart, project.parsedEnd);
                    const colors = STATUS_COLORS[project.status] || STATUS_COLORS["Angebot"];
                    const opacity = project.wahrscheinlichkeit / 100;
                    const isSource = dragSource === project.id;
                    const isTarget = dragTarget === project.id;
                    const { incoming, outgoing } = depListForProject(project.id);

                    return (
                      <div
                        key={project.id}
                        className={`flex border-b border-slate-100 transition-colors ${
                          idx % 2 === 0 ? "bg-white" : "bg-slate-50/30"
                        } ${isSource ? "bg-amber-50" : ""} ${isTarget ? "bg-green-50" : ""} ${
                          dragMode ? "cursor-crosshair" : "hover:bg-slate-50/50"
                        }`}
                        onMouseEnter={() => handleBarMouseEnter(project.id)}
                        onMouseLeave={handleBarMouseLeave}
                      >
                        {/* Project Name */}
                        <div className="w-[280px] min-w-[280px] px-4 py-3 border-r border-slate-200">
                          <div className="flex items-start gap-2">
                            <div className="flex-1 min-w-0">
                              <p className="text-sm font-medium text-slate-900 truncate">
                                {project.kunde}
                              </p>
                              <p className="text-xs text-slate-500 truncate">
                                {project.projekt}
                              </p>
                              {(incoming.length > 0 || outgoing.length > 0) && (
                                <div className="flex gap-1 mt-1">
                                  {incoming.length > 0 && (
                                    <span className="text-[9px] bg-violet-100 text-violet-700 px-1 rounded">
                                      {incoming.length} Vorgänger
                                    </span>
                                  )}
                                  {outgoing.length > 0 && (
                                    <span className="text-[9px] bg-blue-100 text-blue-700 px-1 rounded">
                                      {outgoing.length} Nachfolger
                                    </span>
                                  )}
                                </div>
                              )}
                            </div>
                            <Badge
                              variant="outline"
                              className={`text-[10px] px-1.5 py-0 shrink-0 ${colors.bg} ${colors.text} border-0`}
                            >
                              {project.status}
                            </Badge>
                          </div>
                        </div>

                        {/* Timeline Bar */}
                        <div className="flex-1 relative py-2 px-1">
                          {/* Today line */}
                          {todayPosition >= 0 && todayPosition <= 100 && (
                            <div
                              className="absolute top-0 bottom-0 w-px border-l-2 border-dashed border-red-400 z-10"
                              style={{ left: `${todayPosition}%` }}
                            />
                          )}

                          {/* Project Bar */}
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <div
                                ref={(el) => {
                                  if (el) barRefs.current.set(project.id, el);
                                }}
                                className={`absolute top-1/2 -translate-y-1/2 h-7 rounded-md transition-all ${
                                  dragMode
                                    ? "cursor-grab active:cursor-grabbing hover:ring-2 hover:ring-amber-400"
                                    : "cursor-pointer hover:h-8 hover:shadow-md"
                                } ${isSource ? "ring-2 ring-amber-500 shadow-lg" : ""} ${isTarget ? "ring-2 ring-green-500 shadow-lg" : ""}`}
                                style={{
                                  left: `${pos.left}%`,
                                  width: `${pos.width}%`,
                                  backgroundColor: colors.bar,
                                  opacity: Math.max(0.4, opacity),
                                  zIndex: isSource || isTarget ? 15 : 5,
                                }}
                                onMouseDown={(e) => handleBarMouseDown(project.id, e)}
                              >
                                {pos.width > 8 && (
                                  <span className="absolute inset-0 flex items-center px-2 text-[10px] font-medium text-white truncate">
                                    {project.projekt}
                                  </span>
                                )}
                                {project.wahrscheinlichkeit < 100 && (
                                  <span className="absolute -top-4 left-0 text-[9px] text-slate-400">
                                    {project.wahrscheinlichkeit}%
                                  </span>
                                )}
                              </div>
                            </TooltipTrigger>
                            <TooltipContent side="top" className="max-w-xs">
                              <div className="space-y-1">
                                <p className="font-semibold">{project.kunde} — {project.projekt}</p>
                                <p className="text-xs">Status: {project.status}</p>
                                <p className="text-xs">
                                  Zeitraum: {formatDate(project.parsedStart)} — {formatDate(project.parsedEnd)}
                                </p>
                                <p className="text-xs">Wahrscheinlichkeit: {project.wahrscheinlichkeit}%</p>
                                {project.stunden && (
                                  <p className="text-xs">Stunden: {project.stunden.toLocaleString("de-DE")}</p>
                                )}
                                {project.ktmLead && (
                                  <p className="text-xs">KTM Lead: {project.ktmLead}</p>
                                )}
                                {incoming.length > 0 && (
                                  <p className="text-xs text-violet-600">
                                    Vorgänger: {incoming.map(d => {
                                      const p = projects?.find(pr => pr.id === d.fromId);
                                      return p ? p.projekt : `#${d.fromId}`;
                                    }).join(", ")}
                                  </p>
                                )}
                                {outgoing.length > 0 && (
                                  <p className="text-xs text-blue-600">
                                    Nachfolger: {outgoing.map(d => {
                                      const p = projects?.find(pr => pr.id === d.toId);
                                      return p ? p.projekt : `#${d.toId}`;
                                    }).join(", ")}
                                  </p>
                                )}
                                {dragMode && (
                                  <p className="text-xs text-amber-600 font-medium mt-1">
                                    Klicken und ziehen zum Verbinden
                                  </p>
                                )}
                              </div>
                            </TooltipContent>
                          </Tooltip>
                        </div>
                      </div>
                    );
                  })}

                  {/* SVG Overlay for dependency lines */}
                  <svg
                    className="absolute inset-0 pointer-events-none"
                    style={{ width: "100%", height: "100%", zIndex: 12 }}
                  >
                    <g style={{ pointerEvents: "auto" }}>
                      {renderDependencyLines()}
                      {renderDragLine()}
                    </g>
                  </svg>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Projects without dates */}
        {projectsWithoutDates.length > 0 && (
          <Card className="mt-6">
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <Info className="h-4 w-4 text-amber-500" />
                Projekte ohne Zeitdaten ({projectsWithoutDates.length})
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-slate-500 mb-3">
                Die folgenden Projekte haben keine Start- oder Enddaten und werden nicht in der Timeline angezeigt.
                Ergänzen Sie die Daten in der Projektübersicht.
              </p>
              <div className="flex flex-wrap gap-2">
                {projectsWithoutDates.map((p) => (
                  <Badge key={p.id} variant="outline" className="text-xs">
                    {p.kunde} — {p.projekt}
                  </Badge>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Summary */}
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 mt-6">
          <Card>
            <CardContent className="pt-6">
              <div className="text-center">
                <p className="text-3xl font-bold text-[#005CA9]">{filteredProjects.length}</p>
                <p className="text-sm text-slate-500 mt-1">Projekte in Timeline</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="text-center">
                <p className="text-3xl font-bold text-emerald-600">
                  {filteredProjects.filter((p) => p.status === "läuft").length}
                </p>
                <p className="text-sm text-slate-500 mt-1">Laufende Projekte</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="text-center">
                <p className="text-3xl font-bold text-violet-600">{dependencies.length}</p>
                <p className="text-sm text-slate-500 mt-1">Abhängigkeiten</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="text-center">
                <p className="text-3xl font-bold text-amber-600">{projectsWithoutDates.length}</p>
                <p className="text-sm text-slate-500 mt-1">Ohne Zeitdaten</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>

      <Footer />

      {/* Delete Dependency Confirmation */}
      <AlertDialog open={deleteConfirm !== null} onOpenChange={(open) => !open && setDeleteConfirm(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Abhängigkeit entfernen?</AlertDialogTitle>
            <AlertDialogDescription>
              {deleteConfirm && (
                <>
                  Möchten Sie die Abhängigkeit zwischen{" "}
                  <strong>{projects?.find(p => p.id === deleteConfirm.fromId)?.projekt || `#${deleteConfirm.fromId}`}</strong>
                  {" → "}
                  <strong>{projects?.find(p => p.id === deleteConfirm.toId)?.projekt || `#${deleteConfirm.toId}`}</strong>
                  {" "}wirklich entfernen?
                </>
              )}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Abbrechen</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deleteConfirm && handleDeleteDependency(deleteConfirm.fromId, deleteConfirm.toId)}
              className="bg-red-500 hover:bg-red-600"
            >
              Entfernen
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
