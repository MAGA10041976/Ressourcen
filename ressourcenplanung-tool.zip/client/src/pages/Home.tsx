/*
 * ZETA Corporate Design
 * - Montserrat for headlines, Inter for body
 * - Dark Blue (#07284A) text, Primary Blue (#005CA9) accents
 * - Clean white background with professional layout
 * - Numbered sections with blue accent line
 */

import { useMemo } from "react";
import { motion } from "framer-motion";
import { getStats } from "@/lib/data";
import { HeroSection } from "@/components/HeroSection";
import { StatsOverview } from "@/components/StatsOverview";
import { ProjectTable } from "@/components/ProjectTable";
import { ForecastPipeline } from "@/components/ForecastPipeline";
import { ResourceChart } from "@/components/ResourceChart";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";

export default function Home() {
  const { data: dbProjects, isLoading } = trpc.projects.list.useQuery();
  const { isAuthenticated } = useAuth();
  const stats = useMemo(() => getStats(dbProjects ?? []), [dbProjects]);

  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      <HeroSection stats={stats} />

      {/* Section 01: Kennzahlen */}
      <section id="kennzahlen" className="py-20 lg:py-28 bg-[#f8f9fb]">
        <div className="container">
          <SectionHeader number="01" title="Kennzahlen" subtitle="Ihre aktuelle Projektlandschaft auf einen Blick" />
          <StatsOverview stats={stats} />
        </div>
      </section>

      {/* Section 02: Projektübersicht */}
      <section id="projekte" className="py-20 lg:py-28 bg-white">
        <div className="container">
          <SectionHeader number="02" title="Projektübersicht" subtitle="Alle Projekte der Abteilung Automation im Detail" />
          <ProjectTable projects={dbProjects ?? []} isLoading={isLoading} isAuthenticated={isAuthenticated} />
        </div>
      </section>

      {/* Section 03: Forecast */}
      <section id="forecast" className="py-20 lg:py-28 bg-[#f8f9fb]">
        <div className="container">
          <SectionHeader number="03" title="Forecast & Pipeline" subtitle="Gewichtete Projektwahrscheinlichkeiten und Ressourcenauslastung" />
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mt-12">
            <ForecastPipeline stats={stats} />
            <ResourceChart stats={stats} />
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}

function SectionHeader({ number, title, subtitle }: { number: string; title: string; subtitle: string }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-100px" }}
      transition={{ duration: 0.6, ease: "easeOut" }}
      className="flex items-start gap-6 mb-12"
    >
      <span className="font-serif text-[5rem] lg:text-[7rem] leading-none text-[#005CA9]/10 select-none hidden sm:block font-bold">
        {number}
      </span>
      <div className="pt-4 lg:pt-8">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-8 h-0.5 bg-[#005CA9]" />
          <span className="text-[#005CA9] font-semibold text-sm tracking-widest uppercase">Sektion {number}</span>
        </div>
        <h2 className="font-serif text-3xl lg:text-5xl text-foreground tracking-tight font-bold">
          {title}
        </h2>
        <p className="text-muted-foreground mt-2 text-lg max-w-xl">
          {subtitle}
        </p>
      </div>
    </motion.div>
  );
}
