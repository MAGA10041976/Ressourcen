import { getLoginUrl } from "@/const";
import { LogIn, Shield } from "lucide-react";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";

const LOGO_URL = "https://d2w4bkbcgs5m5g.cloudfront.net/ressourcenplanung-tool/zeta-logo.png";

export default function Login() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-[#07284A] to-[#005CA9] flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-8 text-center"
      >
        <img
          src={LOGO_URL}
          alt="ZETA Logo"
          className="h-12 mx-auto mb-6"
        />

        <h1 className="text-2xl font-bold text-[#07284A] mb-3" style={{ fontFamily: "'Montserrat', sans-serif" }}>
          Ressourcenplanung
        </h1>
        <p className="text-sm uppercase tracking-widest text-[#005CA9] font-semibold mb-6">
          Abteilung Automation
        </p>

        <p className="text-gray-600 mb-8 leading-relaxed">
          Bitte melden Sie sich an, um auf das Ressourcenplanungs-Tool zuzugreifen.
          Nach der Anmeldung muss ein Administrator Ihren Zugang freischalten.
        </p>

        <Button
          onClick={() => { window.location.href = getLoginUrl(); }}
          className="w-full bg-[#005CA9] hover:bg-[#004A8A] text-white py-3 text-base"
        >
          <LogIn className="w-5 h-5 mr-2" />
          Anmelden
        </Button>

        <div className="mt-6 flex items-center gap-2 justify-center text-xs text-gray-400">
          <Shield className="w-3 h-3" />
          <span>Geschützter Bereich - Nur für autorisierte Mitarbeiter</span>
        </div>
      </motion.div>
    </div>
  );
}
