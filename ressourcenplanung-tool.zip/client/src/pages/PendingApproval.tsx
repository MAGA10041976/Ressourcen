import { useAuth } from "@/_core/hooks/useAuth";
import { Clock, ShieldCheck, LogOut } from "lucide-react";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";

export default function PendingApproval() {
  const { user, logout } = useAuth();

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#07284A] to-[#005CA9] flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-8 text-center"
      >
        <div className="w-16 h-16 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-6">
          <Clock className="w-8 h-8 text-amber-600" />
        </div>

        <h1 className="text-2xl font-bold text-[#07284A] mb-3" style={{ fontFamily: "'Montserrat', sans-serif" }}>
          Zugang ausstehend
        </h1>

        <p className="text-gray-600 mb-6 leading-relaxed">
          Willkommen{user?.name ? `, ${user.name}` : ""}! Ihre Registrierung wurde erfolgreich durchgeführt.
          Ein Administrator muss Ihren Zugang erst freischalten, bevor Sie die Ressourcenplanung nutzen können.
        </p>

        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
          <div className="flex items-center gap-2 text-[#005CA9] font-semibold mb-1">
            <ShieldCheck className="w-4 h-4" />
            <span>Was passiert als nächstes?</span>
          </div>
          <p className="text-sm text-gray-600">
            Der Administrator wird Ihre Anfrage prüfen und Ihren Zugang freischalten.
            Sie erhalten automatisch Zugriff, sobald die Freischaltung erfolgt ist.
            Bitte laden Sie diese Seite erneut, nachdem Sie informiert wurden.
          </p>
        </div>

        <div className="flex gap-3 justify-center">
          <Button
            variant="outline"
            onClick={() => window.location.reload()}
            className="border-[#005CA9] text-[#005CA9] hover:bg-[#005CA9] hover:text-white"
          >
            Seite neu laden
          </Button>
          <Button
            variant="ghost"
            onClick={() => logout()}
            className="text-gray-500 hover:text-red-600"
          >
            <LogOut className="w-4 h-4 mr-2" />
            Abmelden
          </Button>
        </div>
      </motion.div>
    </div>
  );
}
