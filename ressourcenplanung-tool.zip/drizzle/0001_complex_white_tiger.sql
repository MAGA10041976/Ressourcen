CREATE TABLE `projects` (
	`id` int AUTO_INCREMENT NOT NULL,
	`kunde` varchar(255) NOT NULL,
	`projekt` varchar(255) NOT NULL,
	`status` enum('Angebot','BD','BD/DD','CD','DD','läuft') NOT NULL DEFAULT 'Angebot',
	`geplanterStart` varchar(100) DEFAULT '',
	`bestellung` int NOT NULL DEFAULT 0,
	`mentorSupport` varchar(500) DEFAULT '',
	`ktmLead` varchar(500) DEFAULT '',
	`mitarbeiter` varchar(500) DEFAULT '',
	`qaa` varchar(500) DEFAULT '',
	`stunden` int,
	`wahrscheinlichkeit` int NOT NULL DEFAULT 50,
	`bemerkung` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `projects_id` PRIMARY KEY(`id`)
);
