CREATE TABLE `activity_logs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`userName` varchar(255) DEFAULT '',
	`action` enum('create','update','delete','login','logout','approve_user','reject_user','change_role','csv_import','csv_export') NOT NULL,
	`entity` enum('project','user','system') NOT NULL,
	`entityId` int,
	`entityName` varchar(255) DEFAULT '',
	`details` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `activity_logs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `projects` ADD `startDate` varchar(10) DEFAULT '';--> statement-breakpoint
ALTER TABLE `projects` ADD `endDate` varchar(10) DEFAULT '';--> statement-breakpoint
ALTER TABLE `projects` ADD `dependencies` varchar(500) DEFAULT '';--> statement-breakpoint
ALTER TABLE `users` ADD `status` enum('pending','approved','rejected') DEFAULT 'pending' NOT NULL;