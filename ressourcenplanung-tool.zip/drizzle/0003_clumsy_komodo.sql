CREATE TABLE `messages` (
	`id` int AUTO_INCREMENT NOT NULL,
	`fromUserId` int NOT NULL,
	`fromUserName` varchar(255) DEFAULT '',
	`toUserId` int NOT NULL,
	`toUserName` varchar(255) DEFAULT '',
	`subject` varchar(500) NOT NULL,
	`content` text NOT NULL,
	`isRead` int NOT NULL DEFAULT 0,
	`category` enum('info','rejection','suspension','approval','general') NOT NULL DEFAULT 'general',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `messages_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `activity_logs` MODIFY COLUMN `action` enum('create','update','delete','login','logout','approve_user','reject_user','change_role','csv_import','csv_export','send_message') NOT NULL;