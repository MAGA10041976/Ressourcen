import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * status: pending (new user, waiting for admin approval), approved (can access), rejected (denied access)
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  status: mysqlEnum("status", ["pending", "approved", "rejected"]).default("pending").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Projects table for resource planning.
 */
export const projects = mysqlTable("projects", {
  id: int("id").autoincrement().primaryKey(),
  kunde: varchar("kunde", { length: 255 }).notNull(),
  projekt: varchar("projekt", { length: 255 }).notNull(),
  status: mysqlEnum("status", ["Angebot", "BD", "BD/DD", "CD", "DD", "läuft"]).notNull().default("Angebot"),
  geplanterStart: varchar("geplanterStart", { length: 100 }).default(""),
  bestellung: int("bestellung").notNull().default(0),
  mentorSupport: varchar("mentorSupport", { length: 500 }).default(""),
  ktmLead: varchar("ktmLead", { length: 500 }).default(""),
  mitarbeiter: varchar("mitarbeiter", { length: 500 }).default(""),
  qaa: varchar("qaa", { length: 500 }).default(""),
  stunden: int("stunden"),
  wahrscheinlichkeit: int("wahrscheinlichkeit").notNull().default(50),
  bemerkung: text("bemerkung"),
  // Gantt-Timeline fields
  startDate: varchar("startDate", { length: 10 }).default(""),  // YYYY-MM-DD
  endDate: varchar("endDate", { length: 10 }).default(""),      // YYYY-MM-DD
  dependencies: varchar("dependencies", { length: 500 }).default(""),  // comma-separated project IDs
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Project = typeof projects.$inferSelect;
export type InsertProject = typeof projects.$inferInsert;

/**
 * Activity log table for tracking user actions.
 */
export const activityLogs = mysqlTable("activity_logs", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  userName: varchar("userName", { length: 255 }).default(""),
  action: mysqlEnum("action", ["create", "update", "delete", "login", "logout", "approve_user", "reject_user", "change_role", "csv_import", "csv_export", "send_message"]).notNull(),
  entity: mysqlEnum("entity", ["project", "user", "system"]).notNull(),
  entityId: int("entityId"),
  entityName: varchar("entityName", { length: 255 }).default(""),
  details: text("details"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ActivityLog = typeof activityLogs.$inferSelect;
export type InsertActivityLog = typeof activityLogs.$inferInsert;

/**
 * Messages table for admin-to-user communication.
 * Used when admin rejects/blocks a user or wants to send information.
 */
export const messages = mysqlTable("messages", {
  id: int("id").autoincrement().primaryKey(),
  fromUserId: int("fromUserId").notNull(),
  fromUserName: varchar("fromUserName", { length: 255 }).default(""),
  toUserId: int("toUserId").notNull(),
  toUserName: varchar("toUserName", { length: 255 }).default(""),
  subject: varchar("subject", { length: 500 }).notNull(),
  content: text("content").notNull(),
  isRead: int("isRead").notNull().default(0),
  category: mysqlEnum("category", ["info", "rejection", "suspension", "approval", "general"]).notNull().default("general"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Message = typeof messages.$inferSelect;
export type InsertMessage = typeof messages.$inferInsert;
