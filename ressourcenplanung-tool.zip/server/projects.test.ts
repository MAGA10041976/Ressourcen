import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

function createPublicContext(): TrpcContext {
  return {
    user: null,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };
}

function createAuthContext(
  role: "user" | "admin" = "admin",
  id = 1,
  status: "pending" | "approved" | "rejected" = "approved"
): TrpcContext {
  return {
    user: {
      id,
      openId: `test-user-${id}`,
      email: `test${id}@zeta.com`,
      name: `Test User ${id}`,
      loginMethod: "manus",
      role,
      status,
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };
}

describe("projects router", () => {
  it("rejects list for unauthenticated users (access control)", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    await expect(caller.projects.list()).rejects.toThrow();
  });

  it("rejects list for pending users (access control)", async () => {
    const ctx = createAuthContext("user", 99, "pending");
    const caller = appRouter.createCaller(ctx);
    await expect(caller.projects.list()).rejects.toThrow();
  });

  it("allows list for approved users", async () => {
    const ctx = createAuthContext("user", 1, "approved");
    const caller = appRouter.createCaller(ctx);
    const result = await caller.projects.list();

    expect(Array.isArray(result)).toBe(true);
    expect(result.length).toBeGreaterThan(0);

    const project = result[0];
    expect(project).toHaveProperty("id");
    expect(project).toHaveProperty("kunde");
    expect(project).toHaveProperty("projekt");
    expect(project).toHaveProperty("status");
    expect(project).toHaveProperty("wahrscheinlichkeit");
    expect(project).toHaveProperty("bestellung");
  });

  it("allows list for admin users regardless of status", async () => {
    const ctx = createAuthContext("admin", 1, "pending");
    const caller = appRouter.createCaller(ctx);
    const result = await caller.projects.list();
    expect(Array.isArray(result)).toBe(true);
  });

  it("rejects create without authentication", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.projects.create({
        kunde: "Unauthenticated",
        projekt: "NOAUTH",
        status: "Angebot",
      })
    ).rejects.toThrow();
  });

  it("rejects update without authentication", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.projects.update({
        id: 1,
        data: { bemerkung: "Should fail" },
      })
    ).rejects.toThrow();
  });

  it("rejects delete without authentication", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.projects.delete({ id: 1 })
    ).rejects.toThrow();
  });

  it("creates a new project with authentication", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const newProject = {
      kunde: "Test Kunde Auth",
      projekt: "TAUTH1",
      status: "Angebot" as const,
      geplanterStart: "KW 20",
      bestellung: 0,
      mentorSupport: "Test Mentor",
      ktmLead: "Test Lead",
      mitarbeiter: "Test Mitarbeiter",
      qaa: "Test QAA",
      stunden: 100,
      wahrscheinlichkeit: 75,
      bemerkung: "Testprojekt mit Auth",
    };

    const result = await caller.projects.create(newProject);
    expect(result).toBeDefined();
    expect(result).toHaveProperty("id");

    // Verify the project was created
    const allProjects = await caller.projects.list();
    const found = allProjects.find((p) => p.projekt === "TAUTH1");
    expect(found).toBeDefined();
    expect(found?.kunde).toBe("Test Kunde Auth");
    expect(found?.wahrscheinlichkeit).toBe(75);
  });

  it("updates an existing project with authentication", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const allProjects = await caller.projects.list();
    const testProject = allProjects.find((p) => p.projekt === "TAUTH1");
    expect(testProject).toBeDefined();

    const updateResult = await caller.projects.update({
      id: testProject!.id,
      data: {
        wahrscheinlichkeit: 90,
        status: "läuft",
        bemerkung: "Aktualisiert durch Auth-Test",
      },
    });

    expect(updateResult).toBeDefined();

    const updatedProjects = await caller.projects.list();
    const updated = updatedProjects.find((p) => p.id === testProject!.id);
    expect(updated?.wahrscheinlichkeit).toBe(90);
    expect(updated?.status).toBe("läuft");
    expect(updated?.bemerkung).toBe("Aktualisiert durch Auth-Test");
  });

  it("deletes a project with authentication", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const allProjects = await caller.projects.list();
    const testProject = allProjects.find((p) => p.projekt === "TAUTH1");
    expect(testProject).toBeDefined();

    const deleteResult = await caller.projects.delete({ id: testProject!.id });
    expect(deleteResult).toEqual({ success: true });

    const afterDelete = await caller.projects.list();
    const found = afterDelete.find((p) => p.projekt === "TAUTH1");
    expect(found).toBeUndefined();
  });

  it("validates required fields on create", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.projects.create({
        kunde: "",
        projekt: "TEST02",
        status: "Angebot",
      })
    ).rejects.toThrow();
  });

  it("validates wahrscheinlichkeit range", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.projects.create({
        kunde: "Test",
        projekt: "TEST03",
        status: "Angebot",
        wahrscheinlichkeit: 150,
      })
    ).rejects.toThrow();
  });

  it("creates project with Gantt fields (startDate, endDate, dependencies)", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.projects.create({
      kunde: "Gantt Test AG",
      projekt: "GANTT1",
      status: "BD",
      startDate: "2026-03-01",
      endDate: "2026-06-30",
      dependencies: "1,2",
    });

    expect(result).toBeDefined();
    expect(result.startDate).toBe("2026-03-01");
    expect(result.endDate).toBe("2026-06-30");
    expect(result.dependencies).toBe("1,2");

    // Clean up
    await caller.projects.delete({ id: result.id });
  });
});

describe("CSV export", () => {
  it("exports projects as CSV string (approved user)", async () => {
    const ctx = createAuthContext("user", 1, "approved");
    const caller = appRouter.createCaller(ctx);
    const csv = await caller.projects.exportCsv();

    expect(typeof csv).toBe("string");
    // Should contain BOM
    expect(csv.startsWith("\uFEFF")).toBe(true);
    // Should contain headers
    expect(csv).toContain("Kunde");
    expect(csv).toContain("Projekt");
    expect(csv).toContain("Status");
    // Should contain semicolons as separator
    expect(csv).toContain(";");
    // Should have multiple lines
    const lines = csv.split("\n");
    expect(lines.length).toBeGreaterThan(1);
  });

  it("rejects CSV export for unauthenticated users", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    await expect(caller.projects.exportCsv()).rejects.toThrow();
  });
});

describe("CSV import", () => {
  it("rejects import without authentication", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.projects.importCsv({
        csvData: "Kunde;Projekt;Status\nTest;TEST;Angebot",
      })
    ).rejects.toThrow();
  });

  it("imports projects from CSV with authentication", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const csvData = [
      "Kunde;Projekt;Status;Geplanter Start;Bestellung;Mentor/Support;KTM Lead;Mitarbeiter;QAA;Stunden;Wahrscheinlichkeit;Bemerkung",
      "CSV-Test AG;CSVT1;Angebot;KW 30;Nein;Mentor A;Lead B;Worker C;QAA D;200;85%;CSV Import Test",
    ].join("\n");

    const result = await caller.projects.importCsv({ csvData });
    expect(result).toHaveProperty("imported");
    expect(result.imported).toBe(1);

    // Verify the imported project exists
    const allProjects = await caller.projects.list();
    const found = allProjects.find((p) => p.projekt === "CSVT1");
    expect(found).toBeDefined();
    expect(found?.kunde).toBe("CSV-Test AG");
    expect(found?.wahrscheinlichkeit).toBe(85);
    expect(found?.mentorSupport).toBe("Mentor A");

    // Clean up
    if (found) {
      await caller.projects.delete({ id: found.id });
    }
  });

  it("rejects CSV with missing required fields", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const csvData = [
      "Kunde;Projekt;Status",
      ";MISSING;Angebot",
    ].join("\n");

    await expect(
      caller.projects.importCsv({ csvData })
    ).rejects.toThrow();
  });
});

describe("admin router", () => {
  it("rejects admin access for regular users", async () => {
    const ctx = createAuthContext("user", 99);
    const caller = appRouter.createCaller(ctx);

    await expect(caller.admin.stats()).rejects.toThrow();
  });

  it("rejects admin access for unauthenticated users", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    await expect(caller.admin.stats()).rejects.toThrow();
  });

  it("returns stats for admin users including messages", async () => {
    const ctx = createAuthContext("admin");
    const caller = appRouter.createCaller(ctx);

    const stats = await caller.admin.stats();
    expect(stats).toHaveProperty("totalUsers");
    expect(stats).toHaveProperty("adminUsers");
    expect(stats).toHaveProperty("totalProjects");
    expect(stats).toHaveProperty("offerProjects");
    expect(stats).toHaveProperty("pendingUsers");
    expect(stats).toHaveProperty("approvedUsers");
    expect(stats).toHaveProperty("rejectedUsers");
    expect(stats).toHaveProperty("totalActivityLogs");
    expect(stats).toHaveProperty("totalMessages");
    expect(typeof stats.totalProjects).toBe("number");
    expect(typeof stats.totalMessages).toBe("number");
  });

  it("lists users for admin", async () => {
    const ctx = createAuthContext("admin");
    const caller = appRouter.createCaller(ctx);

    const users = await caller.admin.users.list();
    expect(Array.isArray(users)).toBe(true);
  });

  it("rejects user list for regular users", async () => {
    const ctx = createAuthContext("user", 99);
    const caller = appRouter.createCaller(ctx);

    await expect(caller.admin.users.list()).rejects.toThrow();
  });

  it("returns activity logs for admin", async () => {
    const ctx = createAuthContext("admin");
    const caller = appRouter.createCaller(ctx);

    const result = await caller.admin.activityLogs.list({ limit: 10, offset: 0 });
    expect(result).toHaveProperty("logs");
    expect(result).toHaveProperty("total");
    expect(Array.isArray(result.logs)).toBe(true);
    expect(typeof result.total).toBe("number");
  });

  it("rejects activity logs for regular users", async () => {
    const ctx = createAuthContext("user", 99);
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.admin.activityLogs.list({ limit: 10, offset: 0 })
    ).rejects.toThrow();
  });
});

describe("access control", () => {
  it("rejects pending users from accessing projects", async () => {
    const ctx = createAuthContext("user", 50, "pending");
    const caller = appRouter.createCaller(ctx);

    await expect(caller.projects.list()).rejects.toThrow();
  });

  it("rejects rejected users from accessing projects", async () => {
    const ctx = createAuthContext("user", 51, "rejected");
    const caller = appRouter.createCaller(ctx);

    await expect(caller.projects.list()).rejects.toThrow();
  });

  it("allows admin users regardless of status", async () => {
    const ctx = createAuthContext("admin", 1, "pending");
    const caller = appRouter.createCaller(ctx);

    const result = await caller.projects.list();
    expect(Array.isArray(result)).toBe(true);
  });

  it("allows approved regular users to access projects", async () => {
    const ctx = createAuthContext("user", 1, "approved");
    const caller = appRouter.createCaller(ctx);

    const result = await caller.projects.list();
    expect(Array.isArray(result)).toBe(true);
  });
});

describe("messages router", () => {
  it("sends a message as admin", async () => {
    const ctx = createAuthContext("admin");
    const caller = appRouter.createCaller(ctx);

    const message = await caller.admin.messages.send({
      toUserId: 99,
      subject: "Test-Nachricht",
      content: "Dies ist eine Testnachricht vom Admin.",
      category: "info",
    });

    expect(message).toBeDefined();
    expect(message).toHaveProperty("id");
    expect(message.subject).toBe("Test-Nachricht");
    expect(message.content).toBe("Dies ist eine Testnachricht vom Admin.");
    expect(message.category).toBe("info");
    expect(message.toUserId).toBe(99);
  });

  it("rejects message sending for regular users", async () => {
    const ctx = createAuthContext("user", 99);
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.admin.messages.send({
        toUserId: 1,
        subject: "Nicht erlaubt",
        content: "Sollte fehlschlagen.",
      })
    ).rejects.toThrow();
  });

  it("lists messages as admin", async () => {
    const ctx = createAuthContext("admin");
    const caller = appRouter.createCaller(ctx);

    const result = await caller.admin.messages.list({ limit: 10, offset: 0 });
    expect(result).toHaveProperty("messages");
    expect(result).toHaveProperty("total");
    expect(Array.isArray(result.messages)).toBe(true);
    expect(typeof result.total).toBe("number");
  });

  it("rejects message list for regular users", async () => {
    const ctx = createAuthContext("user", 99);
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.admin.messages.list({ limit: 10, offset: 0 })
    ).rejects.toThrow();
  });

  it("allows users to read their own messages", async () => {
    const ctx = createAuthContext("user", 1, "approved");
    const caller = appRouter.createCaller(ctx);

    const messages = await caller.messages.myMessages();
    expect(Array.isArray(messages)).toBe(true);
  });

  it("returns unread count for authenticated user", async () => {
    const ctx = createAuthContext("user", 1, "approved");
    const caller = appRouter.createCaller(ctx);

    const count = await caller.messages.unreadCount();
    expect(typeof count).toBe("number");
  });

  it("rejects myMessages for unauthenticated users", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    await expect(caller.messages.myMessages()).rejects.toThrow();
  });

  it("validates required fields on message send", async () => {
    const ctx = createAuthContext("admin");
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.admin.messages.send({
        toUserId: 99,
        subject: "",
        content: "Test",
      })
    ).rejects.toThrow();

    await expect(
      caller.admin.messages.send({
        toUserId: 99,
        subject: "Test",
        content: "",
      })
    ).rejects.toThrow();
  });

  it("sends rejection message with correct category", async () => {
    const ctx = createAuthContext("admin");
    const caller = appRouter.createCaller(ctx);

    const message = await caller.admin.messages.send({
      toUserId: 99,
      subject: "Zugang abgelehnt",
      content: "Ihr Zugangsantrag wurde abgelehnt.",
      category: "rejection",
    });

    expect(message.category).toBe("rejection");
    expect(message.subject).toBe("Zugang abgelehnt");
  });
});
