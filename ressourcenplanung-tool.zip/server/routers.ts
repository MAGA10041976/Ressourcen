import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, adminProcedure, router } from "./_core/trpc";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import {
  getAllProjects,
  createProject,
  updateProject,
  deleteProject,
  getAllUsers,
  updateUserRole,
  updateUserStatus,
  deleteUser,
  bulkCreateProjects,
  createActivityLog,
  getActivityLogs,
  getActivityLogCount,
  createMessage,
  getMessagesForUser,
  getAllMessages,
  getMessageCount,
  markMessageAsRead,
  getUnreadMessageCount,
} from "./db";

const projectInput = z.object({
  kunde: z.string().min(1),
  projekt: z.string().min(1),
  status: z.enum(["Angebot", "BD", "BD/DD", "CD", "DD", "läuft"]),
  geplanterStart: z.string().optional().default(""),
  bestellung: z.number().min(0).max(1).optional().default(0),
  mentorSupport: z.string().optional().default(""),
  ktmLead: z.string().optional().default(""),
  mitarbeiter: z.string().optional().default(""),
  qaa: z.string().optional().default(""),
  stunden: z.number().nullable().optional().default(null),
  wahrscheinlichkeit: z.number().min(0).max(100).optional().default(50),
  bemerkung: z.string().nullable().optional().default(""),
  startDate: z.string().optional().default(""),
  endDate: z.string().optional().default(""),
  dependencies: z.string().optional().default(""),
});

// Custom procedure: requires authenticated user with "approved" status
const approvedProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.status !== "approved" && ctx.user.role !== "admin") {
    throw new TRPCError({
      code: "FORBIDDEN",
      message: "Ihr Zugang wurde noch nicht freigeschaltet. Bitte warten Sie auf die Admin-Freischaltung.",
    });
  }
  return next({ ctx });
});

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  projects: router({
    // Leseoperationen erfordern jetzt approved-Status
    list: approvedProcedure.query(async () => {
      return getAllProjects();
    }),

    // Schreiboperationen erfordern approved-Status
    create: approvedProcedure
      .input(projectInput)
      .mutation(async ({ input, ctx }) => {
        const result = await createProject({
          ...input,
          bemerkung: input.bemerkung ?? "",
        });
        // Activity Log
        await createActivityLog({
          userId: ctx.user.id,
          userName: ctx.user.name || "Unbekannt",
          action: "create",
          entity: "project",
          entityId: result.id,
          entityName: `${result.kunde} - ${result.projekt}`,
          details: `Neues Projekt erstellt: ${result.kunde} - ${result.projekt}`,
        });
        return result;
      }),

    update: approvedProcedure
      .input(z.object({
        id: z.number(),
        data: projectInput.partial(),
      }))
      .mutation(async ({ input, ctx }) => {
        const result = await updateProject(input.id, input.data);
        // Activity Log
        const changedFields = Object.keys(input.data).join(", ");
        await createActivityLog({
          userId: ctx.user.id,
          userName: ctx.user.name || "Unbekannt",
          action: "update",
          entity: "project",
          entityId: result.id,
          entityName: `${result.kunde} - ${result.projekt}`,
          details: `Projekt aktualisiert. Geänderte Felder: ${changedFields}`,
        });
        return result;
      }),

    delete: approvedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input, ctx }) => {
        // Get project info before deletion for log
        const allProjects = await getAllProjects();
        const project = allProjects.find(p => p.id === input.id);
        await deleteProject(input.id);
        // Activity Log
        await createActivityLog({
          userId: ctx.user.id,
          userName: ctx.user.name || "Unbekannt",
          action: "delete",
          entity: "project",
          entityId: input.id,
          entityName: project ? `${project.kunde} - ${project.projekt}` : `Projekt #${input.id}`,
          details: `Projekt gelöscht: ${project ? `${project.kunde} - ${project.projekt}` : `ID ${input.id}`}`,
        });
        return { success: true };
      }),

    // CSV-Export
    exportCsv: approvedProcedure.query(async ({ ctx }) => {
      const allProjects = await getAllProjects();
      const headers = [
        "Kunde", "Projekt", "Status", "Geplanter Start", "Bestellung",
        "Mentor/Support", "KTM Lead", "Mitarbeiter", "QAA",
        "Stunden", "Wahrscheinlichkeit (%)", "Bemerkung",
        "Startdatum", "Enddatum", "Abhängigkeiten"
      ];

      const escCsv = (val: string | number | null | undefined): string => {
        const str = val == null ? "" : String(val);
        if (str.includes(",") || str.includes('"') || str.includes("\n") || str.includes(";")) {
          return `"${str.replace(/"/g, '""')}"`;
        }
        return str;
      };

      const rows = allProjects.map(p => [
        escCsv(p.kunde),
        escCsv(p.projekt),
        escCsv(p.status),
        escCsv(p.geplanterStart),
        p.bestellung ? "Ja" : "Nein",
        escCsv(p.mentorSupport),
        escCsv(p.ktmLead),
        escCsv(p.mitarbeiter),
        escCsv(p.qaa),
        p.stunden != null ? String(p.stunden) : "",
        String(p.wahrscheinlichkeit),
        escCsv(p.bemerkung),
        escCsv(p.startDate),
        escCsv(p.endDate),
        escCsv(p.dependencies),
      ].join(";"));

      // Activity Log
      await createActivityLog({
        userId: ctx.user.id,
        userName: ctx.user.name || "Unbekannt",
        action: "csv_export",
        entity: "project",
        entityId: null,
        entityName: "",
        details: `CSV-Export durchgeführt (${allProjects.length} Projekte)`,
      });

      return "\uFEFF" + headers.join(";") + "\n" + rows.join("\n");
    }),

    // CSV-Import
    importCsv: approvedProcedure
      .input(z.object({
        csvData: z.string().min(1),
        replaceAll: z.boolean().optional().default(false),
      }))
      .mutation(async ({ input, ctx }) => {
        const lines = input.csvData
          .replace(/^\uFEFF/, "")
          .split("\n")
          .map(l => l.trim())
          .filter(l => l.length > 0);

        if (lines.length < 2) {
          throw new Error("CSV muss mindestens eine Kopfzeile und eine Datenzeile enthalten.");
        }

        const dataLines = lines.slice(1);

        const parseCsvLine = (line: string): string[] => {
          const result: string[] = [];
          let current = "";
          let inQuotes = false;
          for (let i = 0; i < line.length; i++) {
            const char = line[i];
            if (inQuotes) {
              if (char === '"' && line[i + 1] === '"') {
                current += '"';
                i++;
              } else if (char === '"') {
                inQuotes = false;
              } else {
                current += char;
              }
            } else {
              if (char === '"') {
                inQuotes = true;
              } else if (char === ";" || char === ",") {
                result.push(current.trim());
                current = "";
              } else {
                current += char;
              }
            }
          }
          result.push(current.trim());
          return result;
        };

        const validStatuses = ["Angebot", "BD", "BD/DD", "CD", "DD", "läuft"] as const;

        const projectsToCreate = dataLines.map((line, idx) => {
          const cols = parseCsvLine(line);
          const kunde = cols[0] || "";
          const projekt = cols[1] || "";
          if (!kunde || !projekt) {
            throw new Error(`Zeile ${idx + 2}: Kunde und Projekt sind Pflichtfelder.`);
          }

          const rawStatus = cols[2] || "Angebot";
          const status = validStatuses.includes(rawStatus as any)
            ? (rawStatus as typeof validStatuses[number])
            : "Angebot";

          const bestellungStr = (cols[4] || "").toLowerCase();
          const bestellung = bestellungStr === "ja" || bestellungStr === "1" ? 1 : 0;

          const stundenStr = cols[9] || "";
          const stunden = stundenStr ? parseInt(stundenStr, 10) : null;

          const wahrscheinlichkeitStr = cols[10] || "50";
          let wahrscheinlichkeit = parseInt(wahrscheinlichkeitStr.replace("%", ""), 10);
          if (isNaN(wahrscheinlichkeit)) wahrscheinlichkeit = 50;
          wahrscheinlichkeit = Math.max(0, Math.min(100, wahrscheinlichkeit));

          return {
            kunde,
            projekt,
            status,
            geplanterStart: cols[3] || "",
            bestellung,
            mentorSupport: cols[5] || "",
            ktmLead: cols[6] || "",
            mitarbeiter: cols[7] || "",
            qaa: cols[8] || "",
            stunden: isNaN(stunden as number) ? null : stunden,
            wahrscheinlichkeit,
            bemerkung: cols[11] || "",
            startDate: cols[12] || "",
            endDate: cols[13] || "",
            dependencies: cols[14] || "",
          };
        });

        if (input.replaceAll) {
          const existing = await getAllProjects();
          for (const p of existing) {
            await deleteProject(p.id);
          }
        }

        const count = await bulkCreateProjects(projectsToCreate);

        // Activity Log
        await createActivityLog({
          userId: ctx.user.id,
          userName: ctx.user.name || "Unbekannt",
          action: "csv_import",
          entity: "project",
          entityId: null,
          entityName: "",
          details: `CSV-Import durchgeführt (${count} Projekte importiert${input.replaceAll ? ", bestehende ersetzt" : ""})`,
        });

        return { imported: count };
      }),
  }),

  // Admin-Router
  admin: router({
    users: router({
      list: adminProcedure.query(async () => {
        return getAllUsers();
      }),

      updateRole: adminProcedure
        .input(z.object({
          userId: z.number(),
          role: z.enum(["user", "admin"]),
        }))
        .mutation(async ({ input, ctx }) => {
          const result = await updateUserRole(input.userId, input.role);
          await createActivityLog({
            userId: ctx.user.id,
            userName: ctx.user.name || "Unbekannt",
            action: "change_role",
            entity: "user",
            entityId: input.userId,
            entityName: result?.name || `User #${input.userId}`,
            details: `Rolle geändert zu: ${input.role}`,
          });
          return result;
        }),

      updateStatus: adminProcedure
        .input(z.object({
          userId: z.number(),
          status: z.enum(["pending", "approved", "rejected"]),
        }))
        .mutation(async ({ input, ctx }) => {
          const result = await updateUserStatus(input.userId, input.status);
          const actionMap = {
            approved: "approve_user" as const,
            rejected: "reject_user" as const,
            pending: "change_role" as const,
          };
          await createActivityLog({
            userId: ctx.user.id,
            userName: ctx.user.name || "Unbekannt",
            action: actionMap[input.status],
            entity: "user",
            entityId: input.userId,
            entityName: result?.name || `User #${input.userId}`,
            details: `Benutzerstatus geändert zu: ${input.status}`,
          });
          return result;
        }),

      delete: adminProcedure
        .input(z.object({ userId: z.number() }))
        .mutation(async ({ input, ctx }) => {
          if (input.userId === ctx.user.id) {
            throw new Error("Sie können Ihren eigenen Account nicht löschen.");
          }
          const allUsers = await getAllUsers();
          const user = allUsers.find(u => u.id === input.userId);
          await deleteUser(input.userId);
          await createActivityLog({
            userId: ctx.user.id,
            userName: ctx.user.name || "Unbekannt",
            action: "delete",
            entity: "user",
            entityId: input.userId,
            entityName: user?.name || `User #${input.userId}`,
            details: `Benutzer gelöscht: ${user?.name || `ID ${input.userId}`}`,
          });
          return { success: true };
        }),
    }),

    // Activity Logs
    activityLogs: router({
      list: adminProcedure
        .input(z.object({
          limit: z.number().min(1).max(500).optional().default(50),
          offset: z.number().min(0).optional().default(0),
        }))
        .query(async ({ input }) => {
          const [logs, total] = await Promise.all([
            getActivityLogs(input.limit, input.offset),
            getActivityLogCount(),
          ]);
          return { logs, total };
        }),
    }),

    // Admin-Nachrichten
    messages: router({
      send: adminProcedure
        .input(z.object({
          toUserId: z.number(),
          subject: z.string().min(1, "Betreff ist erforderlich"),
          content: z.string().min(1, "Nachricht ist erforderlich"),
          category: z.enum(["info", "rejection", "suspension", "approval", "general"]).optional().default("general"),
        }))
        .mutation(async ({ input, ctx }) => {
          const allUsers = await getAllUsers();
          const toUser = allUsers.find(u => u.id === input.toUserId);
          const message = await createMessage({
            fromUserId: ctx.user.id,
            fromUserName: ctx.user.name || "Admin",
            toUserId: input.toUserId,
            toUserName: toUser?.name || `User #${input.toUserId}`,
            subject: input.subject,
            content: input.content,
            category: input.category,
          });
          // Activity Log
          await createActivityLog({
            userId: ctx.user.id,
            userName: ctx.user.name || "Admin",
            action: "send_message",
            entity: "user",
            entityId: input.toUserId,
            entityName: toUser?.name || `User #${input.toUserId}`,
            details: `Nachricht gesendet: ${input.subject} (Kategorie: ${input.category})`,
          });
          return message;
        }),

      list: adminProcedure
        .input(z.object({
          limit: z.number().min(1).max(500).optional().default(50),
          offset: z.number().min(0).optional().default(0),
        }))
        .query(async ({ input }) => {
          const [msgs, total] = await Promise.all([
            getAllMessages(input.limit, input.offset),
            getMessageCount(),
          ]);
          return { messages: msgs, total };
        }),
    }),

    // Admin-Statistiken
    stats: adminProcedure.query(async () => {
      const allUsers = await getAllUsers();
      const allProjects = await getAllProjects();
      const logCount = await getActivityLogCount();
      const msgCount = await getMessageCount();
      return {
        totalUsers: allUsers.length,
        adminUsers: allUsers.filter(u => u.role === "admin").length,
        regularUsers: allUsers.filter(u => u.role === "user").length,
        pendingUsers: allUsers.filter(u => u.status === "pending").length,
        approvedUsers: allUsers.filter(u => u.status === "approved").length,
        rejectedUsers: allUsers.filter(u => u.status === "rejected").length,
        totalProjects: allProjects.length,
        activeProjects: allProjects.filter(p => p.status === "läuft").length,
        offerProjects: allProjects.filter(p => p.status === "Angebot").length,
        totalActivityLogs: logCount,
        totalMessages: msgCount,
      };
    }),
  }),

  // User messages (for non-admin users to read their messages)
  messages: router({
    myMessages: protectedProcedure.query(async ({ ctx }) => {
      return getMessagesForUser(ctx.user.id);
    }),

    unreadCount: protectedProcedure.query(async ({ ctx }) => {
      return getUnreadMessageCount(ctx.user.id);
    }),

    markRead: protectedProcedure
      .input(z.object({ messageId: z.number() }))
      .mutation(async ({ input }) => {
        await markMessageAsRead(input.messageId);
        return { success: true };
      }),
  }),
});

export type AppRouter = typeof appRouter;
